import argparse, pathlib, subprocess, datetime, zipfile, json, hashlib
p=argparse.ArgumentParser();p.add_argument('--repo',type=pathlib.Path,required=True);p.add_argument('--apply',action='store_true');p.add_argument('--stage',action='store_true');a=p.parse_args()
root=a.repo.resolve();source=pathlib.Path(__file__).resolve().parent
files=json.loads((source/'files.json').read_text())
def git(*args): return subprocess.run(['git','-C',str(root),*args],check=True)
if a.stage:
 for name,digest in files.items():
  dest=root/name
  if digest is None:
   if dest.exists():raise SystemExit('Expected removed file: '+name)
  elif not dest.is_file() or hashlib.sha256(dest.read_bytes()).hexdigest()!=digest:raise SystemExit('Changed/missing file: '+name)
 git('add','-A','--',*files);print('Update files staged.');raise SystemExit(0)
git('apply','--check',str(source/'layout-v2.patch'))
if not a.apply:print('Patch compatible. Add --apply to install.');raise SystemExit(0)
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
backup=root.parent/('revimed-layout-backup-'+stamp+'.zip')
with zipfile.ZipFile(backup,'x',zipfile.ZIP_DEFLATED) as z:
 for name in files:
  if (root/name).is_file():z.write(root/name,name)
 z.writestr('NEW_FILES.txt','\n'.join(n for n in files if not (root/n).exists()))
git('apply',str(source/'layout-v2.patch'))
print('Installed. Backup:',backup)
