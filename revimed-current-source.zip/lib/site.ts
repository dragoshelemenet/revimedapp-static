export const site = {
 name: "Centrul Medical Revimed PLUS+",
 shortName: "Revimed PLUS+",
 url: (process.env.NEXT_PUBLIC_SITE_URL || process.env.SITE_URL || "https://revimed.site").replace(/\/+$/, ""),
 description:
  "Centru medical în Chișinău pentru neurologie, neurochirurgie, reabilitare medicală, fizioterapie, diagnostic funcțional și instrumente digitale pentru pacienți.",
 phone: "022 60 50 60",
 phone2: "+373 79 422 908",
 email: "revimed@revimed.md",
 address: "Str. Mircea cel Bătrân 13/2",
 hours: "Luni–Vineri: 09:00–15:00",
 image: "/images/medical-bg.jpg"
};

export const services = [
 {
  title: "Neurological consult",
  slug: "consultatie-neurologica",
  icon: "https://img.icons8.com/color/96/brain.png",
  image: "/images/about-us.jpg",
  description:
   "Consultație neurologică pentru cefalee, amețeli, amorțeli, dureri neuropate, tulburări de somn și simptome ale sistemului nervos.",
  keywords:
   "neurolog Chișinău, consultație neurologică, dureri de cap, amețeli, amorțeli, neuropatie"
 },
 {
  title: "Neuro-surgery consult",
  slug: "consultatie-neurochirurgicala",
  icon: "https://img.icons8.com/color/96/medical-doctor.png",
  image: "/images/medical-bg.jpg",
  description:
   "Consultație neurochirurgicală pentru hernie de disc, dureri lombare și cervicale, radiculopatii și patologii ale coloanei.",
  keywords:
   "neurochirurg Chișinău, hernie de disc, dureri lombare, dureri cervicale, coloană vertebrală"
 },
 {
  title: "Fizionarație și Reabilitare",
  slug: "fizioterapie-reabilitare",
  icon: "https://img.icons8.com/color/96/physical-therapy.png",
  image: "/images/medical-bg.jpg",
  description:
   "Programe personalizate pentru mobilitate, durere, postură, tonus muscular și recuperare funcțională.",
  keywords:
   "fizioterapie Chișinău, reabilitare medicală, recuperare medicală, kinetoterapie"
 },
 {
  title: "Functional diagnostics",
  slug: "diagnostic-functional",
  icon: "https://img.icons8.com/color/96/heart-health.png",
  image: "/images/medical-bg.jpg",
  description:
   "Diagnostic funcțional pentru evaluarea sistemului nervos, aparatului locomotor, circulației și funcțiilor asociate recuperării.",
  keywords:
   "diagnostic funcțional Chișinău, evaluare neurologică, investigații funcționale"
 },
 {
  title: "Bahmeră Therapy",
  slug: "terapie-bemer",
  icon: "https://img.icons8.com/color/96/spa.png",
  image: "/images/medical-bg.jpg",
  description:
   "Terapie pentru susținerea microcirculației, relaxării și recuperării în cadrul unui plan terapeutic responsabil.",
  keywords:
   "Bemer Chișinău, terapie Bemer, microcirculație, recuperare"
 },
 {
  title: "Electrostimulation",
  slug: "electrostimulare",
  icon: "https://img.icons8.com/color/96/electrical.png",
  image: "/images/medical-bg.jpg",
  description:
   "Proceduri pentru activare musculară, tonifiere, recuperare neuromusculară și suport în dureri cronice.",
  keywords:
   "electrostimulare Chișinău, recuperare musculară, stimulare musculară"
 }
];

export const tools = [
 {
  title: "Ayurveda Dosha Test",
  slug: "test-ayurveda-dosha",
  href: "/aplicatii/teste-si-instrumente/test-ayurveda-dosha",
  tag: "Test integrativ",
  image: "/images/medical-bg.jpg",
  description:
   "Chestionar Vata–Pitta–Kapha cu scor, concluzie și protocol educațional cu doze și contraindicații."
 },
 {
  title: "Respirație Terapeutică",
  slug: "respiratie-terapeutica",
  href: "/aplicatii/teste-si-instrumente/respiratie-terapeutica",
  tag: "Respirație",
  image: "/images/medical-bg.jpg",
  description:
   "Exerciții ghidate de respirație pentru calm, ritm și relaxare."
 },
 {
  title: "REVIMED Yoga Tibetan",
  slug: "revimed-yoga-tibetan",
  href: "/aplicatii/teste-si-instrumente/revimed-yoga-tibetan",
  tag: "Instrument pacient",
  image: "/images/hero-bg.jpg",
  description:
   "Aplicație de respirație ghidată cu programe pentru anxietate, somn, respirație, cardiovascular, digestiv și energie."
 },
 {
  title: "Screening neurologic rapid",
  slug: "screening-neurologic",
  href: "/aplicatii/teste-si-instrumente/screening-neurologic",
  tag: "Autoevaluare",
  image: "/images/medical-bg.jpg",
  description:
   "Instrument educațional pentru simptome neurologice și semnale de alarmă."
 }
,
 {
  title: "Calculator Recuperare Personalizată",
  slug: "calculator-recuperare-personalizata",
  href: "/aplicatii/teste-si-instrumente/calculator-recuperare-personalizata",
  tag: "Recuperare",
  image: "/images/medical-bg.jpg",
  description:
   "Instrument educațional care propune pași de recuperare în funcție de durere, mobilitate, zonă afectată și obiectiv."
 },
];
