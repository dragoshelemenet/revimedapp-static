#!/usr/bin/env bash
set -euo pipefail
repo_root="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "Run this inside the revimedapp-static Codespace repository."; exit 1; }
cd "$repo_root"
rm -f -- revimed-batch-01.zip revimed-batch-02.zip revimed-batch-03.zip revimed-batch-04.zip revimed-current-source.zip revimed-display-fix.zip revimed-layout-v2.zip revimed-seo-update.zip revimed-site-cleanup-update.zip revimed-static-dependency-pin.zip revimed-static-optimization-batch-01.zip revimed-static-optimization-batch-02.zip styles/global.css.backup-before-hero-clean
rm -f -- "$repo_root/apply-static-optimization-batch.sh"
echo "Removed old ZIP backups and the obsolete CSS backup. Changes are unstaged for review."
