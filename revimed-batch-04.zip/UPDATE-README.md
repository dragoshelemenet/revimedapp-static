# ReviMed batch 04

Apply after batches 01–03. Upload this ZIP into the Codespace repository root. The installer refuses conflicting local edits and creates a backup; it never commits or pushes. Keep the printed backup path until testing is complete. This archive contains 38 source/configuration changes and one changelog, no build artifacts.

```bash
(
set -e
git pull --ff-only
REPO_DIR="$PWD"
UPDATE_DIR="$(mktemp -d /tmp/revimed-batch04-XXXXXX)"
unzip revimed-batch-04.zip -d "$UPDATE_DIR"
python3 "$UPDATE_DIR/APPLY-UPDATE.py" --repo "$REPO_DIR" --check
python3 "$UPDATE_DIR/APPLY-UPDATE.py" --repo "$REPO_DIR" --apply
npm run build
npm run verify:batch-01
npm run verify:batch-02
python3 scripts/verify-batch-03.py
npm run verify:batch-04
./node_modules/.bin/tsc --noEmit
git diff --check
)
```

No reinstall is needed if batch 03 builds. If dependencies are missing, run `npm ci --no-audit --no-fund` first.

Read docs/refactor/batch-04/CHANGELOG.md for all changes, validation limits and manual tests.

Rollback with the actual paths printed at installation:
```bash
python3 /tmp/revimed-batch04-XXXXXX/APPLY-UPDATE.py --repo "$PWD" --rollback /tmp/revimed-batch04-backup-XXXXXX
npm run build
```
Rollback also refuses files changed since installation. If preflight reports a baseline mismatch, stop and reconcile your local changes; do not force extraction over the repository.
