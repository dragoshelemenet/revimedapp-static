# Batch 04 — metadata coverage, semantics and shared styling

Requires batches 01, 02 and 03. Static export remains enabled. No dependency changes.

## Changes
- lib/seo.ts: optional language alternates, so Romanian-only pages and unpaired blog articles do not advertise missing translations.
- lib/blogMetadata.ts and both blog article routes: article-specific title, description, canonical, article OpenGraph and Twitter image; missing articles use notFound. No invented publication dates or translation pairs.
- lib/toolMetadata.ts, ten tool layouts and two dynamic tool routes: registry-backed metadata for all 44 tool page versions. Client tool implementations remain client components.
- Both app index routes: canonical, descriptions, social metadata and language alternates for four page versions.
- Cookies, terms and FAQ: complete metadata with self canonical and no nonexistent translations.
- Localized video route: noindex for three existing placeholders.
- scripts/generate-search-files.mjs: writes ro/en/ru/uk HTML language attributes into static output before sitemap filtering. Placeholder exclusion is now controlled by their robots metadata.
- LanguageFlagOverlay: synchronizes document language after client navigation; root layout suppresses the intentional root-language hydration difference.
- Header: switching language on an article uses the target blog listing until curated article translation relationships exist. The current-language link retains the current page. Legal/FAQ foreign-language switches still use target-language homepages.
- FAQ: removes duplicate Header/Footer already supplied by root layout.
- App index/tool page wrappers, ServicesPages and EquipmentPages: replace nested main landmarks with div wrappers. Root layout retains the main landmark.
- BlogArticleEnhancer: mounted only on article routes instead of globally, and reruns when pathname changes. This avoids loading its article-processing code as a root-layout dependency on unrelated routes.
- HeroBottomScrollHint: reruns after client navigation to bind to the newly rendered hero.
- lib/appMeta.ts: removes unused yoga fallback; existing registry remains authoritative.
- styles/global.css: replaces 510 repeated color literals with 11 named shared variables, retaining values, specificity, declaration order and importance. No additional !important removal is claimed in this batch.
- package.json and scripts/verify-batch-04.py: adds a comprehensive exported-page verification command.

## Validation
Production static build, TypeScript, batch 01/02/03/04 verifiers and git diff --check passed. All 228 sitemap URLs have self canonicals, descriptions, social metadata, valid alternate targets, correct HTML language and exactly one main landmark. Three video placeholders are noindex.

All 234 HTML files were compared against batch 03. After ignoring scripts, normalizing main/div landmark changes and excluding anchor href attributes (intentional language-switch changes), only the FAQ differed, due to duplicate header/footer removal. This comparison does not test client interactions.

CSS ordered AST equivalence passed after expanding the 11 variables. 510 references changed; no color values or cascade ordering changed. Browser launch failed in this environment, so screenshots, navigation interactions and Core Web Vitals are NOT verified. No measured performance-score improvement is claimed. Existing Turbopack filesystem tracing warning remains.

## Still to do
- Browser visual regression checks on desktop/mobile and interactive tool smoke tests.
- Broader cascade cleanup and removal of remaining unnecessary !important rules after visual validation.
- Curate translated blog pairs and resolve Romanian-content copies under other language prefixes.
- Replace video placeholders with approved content.
- Confirm opening hours before adding them to structured data.
- Asset sizing/compression, Core Web Vitals measurement and deeper component consolidation.
- Narrow legacy filesystem persistence imports to remove the existing build tracing warning.

## Manual checks
Preview out with `python3 -m http.server 3000 --directory out`. Check home, services, equipment, FAQ, blog article and every tool at desktop and mobile widths in all locales. Test menu, language switching, scrolling hint, article download, breathing start/pause/reset and calculator inputs. Confirm FAQ has one header/footer. Navigate between articles without reloading and confirm the export button remains usable.

## Files
- `app/layout.tsx`
- `app/aplicatii/page.tsx`
- `app/intrebari/page.tsx`
- `app/termeni-si-conditii/page.tsx`
- `app/cookies/page.tsx`
- `app/[lang]/aplicatii/page.tsx`
- `app/[lang]/video-uri/page.tsx`
- `app/[lang]/aplicatii/teste-si-instrumente/screening-neurologic/layout.tsx`
- `app/[lang]/aplicatii/teste-si-instrumente/respiratie-terapeutica/layout.tsx`
- `app/[lang]/aplicatii/teste-si-instrumente/test-ayurveda-dosha/layout.tsx`
- `app/[lang]/aplicatii/teste-si-instrumente/calculator-recuperare-personalizata/layout.tsx`
- `app/[lang]/aplicatii/teste-si-instrumente/[slug]/page.tsx`
- `app/[lang]/aplicatii/teste-si-instrumente/revimed-yoga-tibetan/layout.tsx`
- `app/[lang]/blog/[slug]/page.tsx`
- `app/aplicatii/teste-si-instrumente/screening-neurologic/layout.tsx`
- `app/aplicatii/teste-si-instrumente/respiratie-terapeutica/page.tsx`
- `app/aplicatii/teste-si-instrumente/respiratie-terapeutica/layout.tsx`
- `app/aplicatii/teste-si-instrumente/test-ayurveda-dosha/layout.tsx`
- `app/aplicatii/teste-si-instrumente/calculator-recuperare-personalizata/page.tsx`
- `app/aplicatii/teste-si-instrumente/calculator-recuperare-personalizata/layout.tsx`
- `app/aplicatii/teste-si-instrumente/[slug]/page.tsx`
- `app/aplicatii/teste-si-instrumente/revimed-yoga-tibetan/page.tsx`
- `app/aplicatii/teste-si-instrumente/revimed-yoga-tibetan/layout.tsx`
- `app/blog/[slug]/page.tsx`
- `components/ServicesPages.tsx`
- `components/HeroBottomScrollHint.tsx`
- `components/EquipmentPages.tsx`
- `components/LanguageFlagOverlay.tsx`
- `components/BlogArticleEnhancer.tsx`
- `components/Header.tsx`
- `lib/appMeta.ts`
- `lib/blogMetadata.ts`
- `lib/seo.ts`
- `lib/toolMetadata.ts`
- `scripts/verify-batch-04.py`
- `scripts/generate-search-files.mjs`
- `styles/global.css`
- `package.json`
