# ReviMed — Batch 02

This update assumes Batch 01 is already applied. Upload `revimed-batch-02.zip` to the Codespaces repository root. At the root, run:

```bash
git pull --ff-only
REPO_DIR="$PWD"
UPDATE_DIR="$(mktemp -d /tmp/revimed-batch02-XXXXXX)"
unzip revimed-batch-02.zip -d "$UPDATE_DIR"
python3 "$UPDATE_DIR/APPLY-UPDATE.py" --repo "$REPO_DIR" --check
python3 "$UPDATE_DIR/APPLY-UPDATE.py" --repo "$REPO_DIR" --apply
npm ci --no-audit --no-fund
npm run build
npm run verify:batch-01
npm run verify:batch-02
./node_modules/.bin/tsc --noEmit
git diff --check
git diff --stat
```

Installer checks all affected files against the Batch 01 state, stops on a mismatch, and saves a rollback backup outside the repository. It never commits or pushes. Resolve mismatches rather than forcing an overwrite. The installer/manifest/readme remain in the temporary extraction folder and do not enter the repository.

For a visual preview after a successful build: `python3 -m http.server 3000 --directory out`, then open forwarded port 3000. The site remains a static export. Read `docs/refactor/batch-02/VERIFICATION.md` and `CHANGELOG.md`.

The metadata work covers the homepage, service pages and equipment pages in Romanian, English, Russian and Ukrainian. Other page families remain for later batches.
