# Batch 02 changelog

Based on the exact Batch 01 package state and the successful Codespaces build reported by the owner. No GitHub writes, commits or pushes were made.

## SEO scope

- `app/page.tsx` already had complete Romanian homepage metadata. Add equivalent shared metadata to `/en/`, `/ru/` and `/ua/` with page-specific titles/descriptions. Canonical, Open Graph URL, Twitter, robots and `ro`/`en`/`ru`/`uk` plus `x-default` alternates are produced by `makeMetadata`.
- Apply the same metadata helper to the Romanian and localized services/equipment listing pages and their detail pages. Metadata uses localized titles/descriptions from the existing content modules and a trailing-slash canonical matching each actual route.
- Titles use the helper's absolute title to prevent the root layout from appending its title template a second time.
- Correct the service slug typo `consultatii-neurochirurgicale` to the content-backed slug `consultatii-neurochirurgie` in both Romanian and localized static route lists. This makes the neurochirurgical service page render, gives it metadata, and puts it in the export-driven sitemap. The misspelled route was an error shell, so no working public content URL is removed.
- Add `verify:batch-02` and `scripts/verify-batch-02.mjs` to check canonical/hreflang/description output for 136 home/service/equipment pages across four locales, plus sitemap inclusion of the fixed route.
- `docs/refactor/batch-02/VERIFICATION.md` records build and checks; this changelog lists every source change.

## Deliberately deferred

Other localized page families (about, prices, contact, gallery, blog, apps, video placeholders), per-article translated slug alternates, dynamic HTML language, navigation links and systematic page-template refactoring remain for later batches. This package does not claim site-wide metadata completion. The site remains Next.js static export.
