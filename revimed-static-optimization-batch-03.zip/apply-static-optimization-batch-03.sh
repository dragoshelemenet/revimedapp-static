#!/usr/bin/env bash
set -euo pipefail

ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || {
  echo "Run this from inside the Revimed Git repository." >&2
  exit 1
}
cd "$ROOT"

if [ "$(git branch --show-current)" != "main" ]; then
  echo "Expected branch main. Current branch: $(git branch --show-current)" >&2
  echo "Switch to main and run git pull --ff-only origin main before applying this batch." >&2
  exit 1
fi

check_clean() {
  local path="$1"
  if git ls-files --error-unmatch "$path" >/dev/null 2>&1; then
    if ! git diff --quiet HEAD -- "$path"; then
      echo "Stopped: $path has local edits. Save or commit those edits before applying this cleanup." >&2
      exit 1
    fi
  fi
}

for path in styles/global.css components/AdminApplicationsManager.tsx lib/auth.ts; do
  check_clean "$path"
done

# These are the only references permitted to disappear with the orphaned files.
if rg -n \
  --glob '!components/AdminApplicationsManager.tsx' \
  --glob '!lib/auth.ts' \
  'AdminApplicationsManager|createAdminSession|requireAdmin|destroyAdminSession|/api/admin/apps' \
  app components lib; then
  echo "Stopped: a live source file still references the old admin uploader/auth helpers." >&2
  exit 1
fi

python3 - <<'PY'
from pathlib import Path
import re

path = Path("styles/global.css")
css = path.read_text(encoding="utf-8")
targets = (
    "htmlDropZone",
    "adminSimpleCard",
    "adminListHead",
    "adminNotice",
    "adminFormSimple",
    "adminTwoCols",
    "adminField",
    "adminLangEditorGrid",
    "adminLangMiniCard",
    "appEditNotice",
    "adminFormActions",
    "replaceHtmlBox",
    "adminAppsList",
    "adminAppRow",
    "adminAppActions",
    "adminSimplePage",
    "adminLoginPage",
    "blogArticleCard",
    "blogReadableContent",
)
rule_pattern = re.compile(r"(?ms)(^|\n)([ \t]*[^@{}\n][^{}]*\{[^{}]*\})")
removed_selectors = 0
removed_blocks = 0

def clean_rule(match):
    global removed_selectors, removed_blocks
    prefix, rule = match.groups()
    brace = rule.find("{")
    selectors = rule[:brace]
    parts = selectors.split(",")
    keep = []
    for selector in parts:
        stale = any(re.search(r"\." + re.escape(name) + r"(?![\w-])", selector) for name in targets)
        if stale:
            removed_selectors += 1
        else:
            keep.append(selector.strip())
    if len(keep) == len(parts):
        return match.group(0)
    removed_blocks += 1
    if not keep:
        return prefix
    declarations = rule[brace + 1:]
    return prefix + ",\n".join(keep) + " {" + declarations

updated = rule_pattern.sub(clean_rule, css)
if removed_selectors != 67:
    raise SystemExit(
        f"Stopped: expected 67 verified obsolete selectors, found {removed_selectors}. "
        "The stylesheet differs from the reviewed version."
    )
if any(re.search(r"\." + re.escape(name) + r"(?![\w-])", updated) for name in targets):
    raise SystemExit("Stopped: an obsolete selector remains after cleanup.")

path.write_text(updated, encoding="utf-8")
print(f"Removed {removed_selectors} obsolete selectors across {removed_blocks} CSS rules.")
print(f"Stylesheet reduced from {len(css.encode()):,} to {len(updated.encode()):,} bytes.")
PY

for path in components/AdminApplicationsManager.tsx lib/auth.ts; do
  if [ -f "$path" ]; then
    rm -- "$path"
  fi
done

old_artifacts=(
  revimed-batch-01.zip
  revimed-batch-02.zip
  revimed-batch-03.zip
  revimed-batch-04.zip
  revimed-current-source.zip
  revimed-display-fix.zip
  revimed-layout-v2.zip
  revimed-seo-update.zip
  revimed-site-cleanup-update.zip
  revimed-static-dependency-pin.zip
  revimed-static-optimization-batch-01.zip
  revimed-static-optimization-batch-02.zip
  styles/global.css.backup-before-hero-clean
)
for path in "${old_artifacts[@]}"; do
  if git ls-files --error-unmatch "$path" >/dev/null 2>&1; then
    check_clean "$path"
    rm -f -- "$path"
  fi
done

# Keep the repository focused on reviewable static-site source after the patch is applied.
rm -f -- apply-static-optimization-batch-03.sh revimed-static-optimization-batch-03.zip

echo
echo "Static cleanup applied. Nothing was staged or committed."
git status --short --branch
