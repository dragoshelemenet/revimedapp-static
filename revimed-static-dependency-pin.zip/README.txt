Revimed static dependency pin patch

Files: package.json and package-lock.json only.
This patch pins package versions already resolved by the current lockfile.

Apply: unzip into the repository root and replace these two files. Then run npm run build. Review git status and commit only the intended files.
DigitalOcean remains Static Site on branch main, build command npm run build, output directory out.
