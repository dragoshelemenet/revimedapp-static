#!/usr/bin/env python3
"""Apply or roll back this archive without overwriting locally changed files."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile


def digest(file):
    return hashlib.sha256(file.read_bytes()).hexdigest() if file.is_file() else None


def target(root, relative):
    file = root / relative
    if not file.resolve().is_relative_to(root.resolve()):
        raise SystemExit(f'Unsafe path: {relative}')
    if file.is_symlink() or (file.exists() and not file.is_file()):
        raise SystemExit(f'Not a regular file: {file}')
    return file


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repo', required=True, type=Path)
action = parser.add_mutually_exclusive_group(required=True)
action.add_argument('--check', action='store_true')
action.add_argument('--apply', action='store_true')
action.add_argument('--rollback', type=Path, metavar='BACKUP_DIRECTORY')
args = parser.parse_args()
repo = args.repo.resolve()
actual_root = Path(subprocess.check_output(['git', '-C', str(repo), 'rev-parse', '--show-toplevel'], text=True).strip()).resolve()
if actual_root != repo:
    raise SystemExit('--repo must be the repository root.')
package = Path(__file__).resolve().parent
manifest = json.loads((package / 'UPDATE-MANIFEST.json').read_text())

if args.rollback:
    backup = args.rollback.resolve()
    saved = json.loads((backup / 'manifest.json').read_text())
    if saved['repository'] != str(repo) or saved['files'] != manifest['files']:
        raise SystemExit('Backup does not match this package and repository.')
    for entry in manifest['files']:
        file = target(repo, entry['path'])
        if digest(file) != entry['after']:
            raise SystemExit(f'Rollback blocked: edited since installation: {entry["path"]}')
        if entry['before'] is not None and digest(target(backup, entry['path'])) != entry['before']:
            raise SystemExit(f'Invalid backup: {entry["path"]}')
    for entry in manifest['files']:
        file = target(repo, entry['path'])
        if entry['before'] is None:
            file.unlink()
        else:
            file.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target(backup, entry['path']), file)
    print('Rolled back batch 03. No git commits were changed.')
else:
    problems = []
    for entry in manifest['files']:
        file = target(repo, entry['path'])
        if digest(file) != entry['before']:
            problems.append(f'Baseline mismatch: {entry["path"]}')
        if entry['after'] is not None and digest(target(package, entry['path'])) != entry['after']:
            problems.append(f'Package checksum mismatch: {entry["path"]}')
    if problems:
        raise SystemExit('\n'.join(problems) + '\nNo files changed. Do not force overwrite; reconcile this package with your current files.')
    print(f'Checks passed for {len(manifest["files"])} files. Base: {manifest["base_commit"]}')
    if args.apply:
        backup = Path(tempfile.mkdtemp(prefix='revimed-batch03-backup-'))
        for entry in manifest['files']:
            file = target(repo, entry['path'])
            if entry['before'] is not None:
                saved = target(backup, entry['path'])
                saved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(file, saved)
        (backup / 'manifest.json').write_text(json.dumps({'repository': str(repo), 'files': manifest['files']}, indent=2))
        for entry in manifest['files']:
            file = target(repo, entry['path'])
            if entry['after'] is None:
                file.unlink()
            else:
                file.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(target(package, entry['path']), file)
        print(f'Applied batch 03. Backup: {backup}')
        print('Run npm ci, npm run build, and python3 scripts/verify-batch-03.py. Nothing was committed or pushed.')
