# Batch 03 — section metadata and navigation

Requires Batch 01 and Batch 02. Site remains a static Next.js export.

## Every modification

- Add `lib/sectionMetadata.ts`: one typed mapping for About, Prices, Contact, Gallery and Blog listing metadata; use existing localized dictionary copy and the shared metadata builder.
- Update `app/{despre-noi,preturi,contact,galerie,blog}/page.tsx`: replace title-only metadata with titles, descriptions, canonical URLs, language alternates, Open Graph/Twitter and robots settings from the shared builder.
- Update the same five `app/[lang]/.../page.tsx` files: add language-validated metadata generation. This covers 20 section pages including Romanian.
- Update `components/Footer.tsx`: tools link now targets the existing `/aplicatii` index; terms and cookies link to existing Romanian pages for every language rather than missing translations. Labels remain localized; destination content is Romanian.
- Update `components/Header.tsx`: FAQ links target the existing Romanian FAQ. On Romanian-only FAQ/legal pages, language switching opens the selected locale's homepage rather than a nonexistent translation. Article language switching remains deferred.
- Add `scripts/verify-batch-03.py`: inspect exported section metadata, language targets and home navigation.
- Add this changelog and package installation instructions. No CSS, content/database, dependency or lockfile changes.

## Verification

Production build and its TypeScript check passed on Node 24.22.1. Batch 01 and Batch 02 checks passed. Batch 03 checks passed for all 20 section pages and home navigation in four languages. Sitemap remains 228 URLs. `git diff --check` passed. Browser screenshot/interaction checks were not performed; visual markup and CSS were not intentionally altered, but navigation destinations changed as described above.

After installation run `npm run build`, both prior verification scripts and `python3 scripts/verify-batch-03.py`. Preview `out` with `python3 -m http.server 3000 --directory out`. Check the five section pages in all locales, footer tools/legal links, header FAQ and language switching from FAQ/legal pages.

## Remaining

Articles and tools still need metadata/translation mapping. HTML language, placeholder indexing policy, article language switching, component/semantic refactoring, broader CSS consolidation, assets and measured performance work remain outstanding. This is another incremental package, not a claim of completed site-wide SEO.
