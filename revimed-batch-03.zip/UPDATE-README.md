# ReviMed Batch 03

Apply after Batch 02. Upload revimed-batch-03.zip into the Codespaces repository root. Run the following block; it stops if a command fails:

```bash
(
set -e
git pull --ff-only
REPO_DIR="$PWD"
UPDATE_DIR="$(mktemp -d /tmp/revimed-batch03-XXXXXX)"
unzip revimed-batch-03.zip -d "$UPDATE_DIR"
python3 "$UPDATE_DIR/APPLY-UPDATE.py" --repo "$REPO_DIR" --check
python3 "$UPDATE_DIR/APPLY-UPDATE.py" --repo "$REPO_DIR" --apply
npm run build
npm run verify:batch-01
npm run verify:batch-02
python3 scripts/verify-batch-03.py
git diff --check
)
```

No dependencies changed; your successful Batch 02 install is sufficient. If dependencies are absent, run npm ci --no-audit --no-fund first. Do not reinstall while another installation is running.

Installer preserves original paths, checks original and replacement checksums, saves a backup, and never commits or pushes. It refuses changed target files. Read docs/refactor/batch-03/CHANGELOG.md for every modification and verification instructions.

To roll back, retain the extraction directory and printed backup directory, then run:
`python3 /tmp/YOUR-EXTRACTION-DIRECTORY/APPLY-UPDATE.py --repo "$PWD" --rollback /tmp/YOUR-BACKUP-DIRECTORY`
Rollback refuses if affected files were edited after installation. Review and commit installed source yourself. Do not commit ZIPs, node_modules or out. The package-only README, manifest and installer are not installed.
