#!/usr/bin/env bash
set -euo pipefail
PATCH_FILE="$(cd "$(dirname "$0")" && pwd)/site-cleanup.patch"
BASE="c1fbec7"
if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo "Rulează scriptul din directorul repo-ului Git." >&2
  exit 1
fi
if ! git merge-base --is-ancestor "$BASE" HEAD; then
  echo "Repo-ul nu conține commitul de bază $BASE; descarcă versiunea actualizată înainte de aplicare." >&2
  exit 1
fi
if ! git apply --check "$PATCH_FILE"; then
  echo "Patch-ul nu se aplică curat peste fișierele curente. Nu s-a modificat nimic." >&2
  exit 1
fi
git apply "$PATCH_FILE"
echo "Actualizarea a fost aplicată. Rulează npm ci și apoi npm run build."
