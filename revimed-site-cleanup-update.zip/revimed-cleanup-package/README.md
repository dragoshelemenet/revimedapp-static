# Revimed site cleanup update

Patch-ul simplifică șabloanele și CSS-ul comun, uniformizează paginile Blog, Întrebări și Utilaje, păstrează hero-ul cu imagine doar pe pagina principală și elimină inițializarea bazei SQLite din randarea publică. Textele și informațiile publice existente sunt incluse în `content/public-pages.json`.

Bază verificată: commitul `c1fbec7` (`Unify page layouts and improve search metadata`).

## Aplicare

1. Descarcă și dezarhivează pachetul.
2. Din directorul repository-ului, rulează `bash /cale/către/pachet/apply-update.sh`.
3. Rulează `npm ci`, apoi `npm run build`.
4. Publică directorul `out` generat de build.

Scriptul verifică baza și compatibilitatea patch-ului înainte să schimbe fișiere. Pachetul nu conține baza SQLite locală, fișiere de preview sau fișierele `out`.
