Static optimization batch 01

Replace these files at the repository root:
- package.json
- package-lock.json
- scripts/build-static.mjs
- scripts/verify-static-release.mjs
- lib/pageTemplates.tsx
- .gitignore

Changes: pin existing package versions; set correct HTML lang on each exported locale (including uk for /ua); prioritize the lead Blog image; remove redundant Blog renderer branches that all returned the same paragraph; expand static verification to cover locale attributes and Blog/Utilaj paths; deduplicate .gitignore entries without changing ignored build outputs.

No layout or published text changes. The ZIP does not modify the repo until extracted. At the Codespace root, check git status --short --branch; if package/build files are clean, run git pull origin main, then extract and overwrite only the listed files. Preserve existing edits. Run npm run build before commit. DigitalOcean stays Static Site on main, build command npm run build, output out.
