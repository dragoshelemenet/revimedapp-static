# Batch 01 changelog

Base commit: `721c7d66ee05b21bc4e7f4742386626952588381`.

## Modified source files

- `styles/global.css`: remove 100 earlier exact duplicate rules only when an identical later rule exists in the same parent scope. Preserve the later copy, selector, declaration order/value/importance, media-query scope, keyframes, responsive behavior and animation definitions. 251 redundant important declarations removed. File drops from 303,334 to 289,602 bytes (13,732 bytes / 4.53%); 4,113 important tokens become 3,862. This is conservative deduplication, not the completed design-system refactor.
- `lib/site.ts`: normalize the configured origin's trailing slashes and support the existing SITE_URL fallback, making it the shared SEO origin.
- `lib/seo.ts`: use shared site URL and an existing default image; protect helper-generated titles from root-template duplication; normalize helper-generated canonical/hreflang URLs to trailing slashes and add x-default. Retain one clinic ID. Remove conflicting/unconfirmed hours and approximate coordinates from its schema (displayed business details remain unchanged). Remove the nonexistent site-search action. Correct JSON-LD less-than escaping and type input as unknown.
- `lib/seoAdvanced.ts`: reuse shared origin, serializer and clinic builder; update MedicalWebPage references to the same clinic ID. Keep existing export names for compatibility. Use the existing site image as its default. Its remaining page metadata migration is deferred to batch 02.
- `app/layout.tsx`: remove two duplicate clinic blocks and their unused imports/local object. Keep the remaining clinic and WebSite schema, all visible markup and client components.
- `package.json`: append search-file generation to the build command; add `verify:batch-01`. No dependency or lockfile changes.

## New source files

- `scripts/generate-search-files.mjs`: read actual `out/**/index.html` files after Next export; generate unique trailing-slash URLs, honoring noindex and excluding internal error output and the existing three localized video placeholders. Load Next environment files, validate the configured site origin, XML-escape URLs, and generate matching robots.txt. Do not fabricate lastmod dates. This replaces competing sitemap sources without maintaining another list of service/article slugs. Exported artifacts remain in ignored `out/`.
- `scripts/verify-batch-01.mjs`: validate sitemap coverage and local targets, noindex exclusions, robots origin, one clinic entity per rendered page, homepage metadata and real JSON-LD serializer round-trip behavior for script-closing input.
- `docs/refactor/batch-01/AUDIT.md`: repository-wide findings, evidence, priorities, design-system direction and staged plan.
- `docs/refactor/batch-01/INVENTORY.json`: baseline inventory of all 129 tracked files, sizes and source-level metrics.
- `docs/refactor/batch-01/CHANGELOG.md`: this complete change record.
- `docs/refactor/batch-01/VERIFICATION.md`: checks run, limitations and manual test instructions.

## Removed source files — installer handles these

- `app/sitemap.ts`: incomplete filesystem-based sitemap that skipped dynamic routes and assigned build timestamps to every URL.
- `public/sitemap.xml`: competing incomplete static sitemap.
- `public/robots.txt`: hardcoded origin; replaced by generated export output.

## Package-only files

`APPLY-UPDATE.py`, `UPDATE-MANIFEST.json`, and `UPDATE-README.md` implement checksum guards, a dry run, backups, installation and guarded rollback. They do not get copied into the repository by the installer.

## Deliberately deferred

All-page metadata/hreflang, reciprocal translated article mapping, server HTML language, broken navigation/service slug repair, removal of nested main landmarks, visual-system consolidation, responsive assets and measured Core Web Vitals improvements. No medical text, pricing, database, visible layout or interactive tool algorithms change in this batch. No GitHub writes or commits were made.
