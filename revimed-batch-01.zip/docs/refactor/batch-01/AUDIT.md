# ReviMed repository audit — before changes

Baseline: `721c7d66ee05b21bc4e7f4742386626952588381` (main). Audit date: 2026-11-11.

## Scope and evidence

Repository-wide source audit: all 129 tracked files inventoried; route generation and metadata exports, component imports and client boundaries, stylesheet structure/cascade, data sources/SQLite schema, static assets, configuration and maintenance scripts examined. The attached INVENTORY.json records every tracked file. This is a technical audit, not a medical-content fact check or a claim that every interaction has been manually exercised.

`npm ci` and untouched `npm run build` succeeded with locked Next.js 16.2.6. There are 234 exported HTML files: 231 route pages plus three standalone not-found outputs (404.html, 404/index.html and _not-found/index.html). Four of those route pages also render the error shell: `/servicii/consultatii-neurochirurgicale/` in all four languages; the hardcoded slug disagrees with service data. Build emits a Turbopack broad filesystem-tracing warning. No existing test/lint scripts or CI workflow are tracked. This leaves 227 rendered content routes, including three localized video placeholders. Browser launch was attempted but blocked by the execution environment (Chromium socket permission failure); visual parity and real Core Web Vitals have NOT been measured.

## Findings, ordered by priority

| Area | Evidence / problem | Remediation |
| --- | --- | --- |
| CSS cascade | styles/global.css: 303,334 bytes, 14,213 lines, 4,113 `!important` tokens. Repeated FINAL/override sections, high-specificity `html body main` selectors, positional `:has()` selectors and overlapping breakpoints. | First remove provably identical earlier rules in the same scope. Then refactor one visual family per batch; never strip all important flags blindly. |
| Canonical/metadata | 231/232 index HTML files outside _not-found lack a canonical (this count includes 404/index.html and four route error shells). 88 inherit the clinic default title. Most localized wrappers have no metadata export. | Introduce shared metadata policy, then migrate every route family with rendered-output tests. |
| Sitemap | app/sitemap.ts skips every dynamic path (localized, services, equipment, articles); also public/sitemap.xml competes for the same output. Runtime timestamps pretend every page was updated at every build. | One sitemap generated from the routes actually exported, with honest dates only. |
| Structured data | app/layout.tsx emits three clinic entities, two IDs and duplicated details. seo.ts and seoAdvanced.ts repeat logic. JSON-LD `<` replacement is a no-op because the string literal evaluates to `<`. WebSite declares an unimplemented `?s=` search. | One clinic entity/ID, shared escaping, remove unsupported search action. |
| Business facts | site.ts/footer say 09:00–15:00; content.ts defaults to 09:00–16:00; schema says 09:00–19:00. Emails differ too. | Do not invent a winner. Omit uncertain schema hours pending owner confirmation; consolidate displayed facts in a later approved content change. |
| Locale semantics | Root document always has `lang="ro"`; `/ua` needs HTML language `uk`. Header changes language by prefixing the same article slug even when translations use different slugs. | Server-render language via a route/layout restructuring; use validated translation groups for language switches. |
| Broken links | Footer tools URL `/aplicatii/teste-si-instrumente` has no page. Localized questions, cookies and terms routes are missing. Header links point there. | Repair navigation with explicit fallback policy; do not invent translations. |
| Content integrity | staticBlogPosts contains Romanian text labelled as other languages; some duplicated articles. Localized video routes display Contact and a placeholder. | Curate translation groups and exclude placeholders from search; preserve medical copy pending editorial review. |
| Assets | Missing `/images/hero-bg.jpg` referenced by SEO and older data/CSS. Two zero-byte files j.jpg/sdf.jpg. 1.jpg is 1.25 MB, logo.png 367 KB, about-us.jpg 606 KB. Three byte-identical image pairs. | Correct SEO image now; later optimize visible assets with screenshot checks and fixed dimensions. |
| Loading | Many raw img tags lack dimensions/lazy loading; hero CSS background discovery; remote icons/equipment photos and embedded video requests. Static export has images.unoptimized=true. | Generate responsive local derivatives and tune critical-image loading; don't enable an unavailable runtime image optimizer. |
| Semantic HTML | Nested main elements in service/equipment/app/questions pages and tools. Article heading appearance is added to paragraphs by DOM mutation. | One main landmark; render article structure in React, preserving styles. |
| Client effects | BlogArticleEnhancer and HeroBottomScrollHint mount globally with empty effect dependencies, so client-side navigation can miss enhancement. Article enhancer rewrites innerHTML. | Scope effects to article/hero components and route changes; preserve download and animation behavior. |
| Components | pageTemplates.tsx combines multiple page families and old unused templates. RevimedSmartTool has 1,029 lines. Five disabled fixer components return null; unused admin manager references APIs absent in this export. | Extract route families, typed reusable components, shared locales and tool definitions; remove verified unreachable code. |
| Data/build | db.ts/content.ts/seedLanguages mutate SQLite at module import; repeated initialization across build workers. Database and static TS/JSON duplicate content. Registry's save serializes a literal backslash-n. | Separate explicit content migrations from reads; consolidate static content only after output comparisons. |
| Maintenance | package.json uses latest ranges but lockfile pins actual versions. Only build script. CSS backup is tracked. | Keep lockfile stable in batch 1; later pin versions, add focused regression checks and remove obsolete backup. |

## Design-system direction

Preserve the current effective styles as the reference. Existing `:root` tokens are the starting palette, not a mandate to recolor the site. Consolidate shell widths, typography, spacing, button variants, cards and hero variants from their final winning declarations. Keep responsive breakpoints and animation timing until parity checks pass. Avoid adding another final override section.

## Progressive batches

1. Conservative CSS deduplication, shared SEO primitives/schema cleanup, reliable sitemap/robots output, verification and installation safeguards.
2. All page metadata/canonicals/hreflang and article translation mapping; placeholder indexing policy; correct server HTML language and navigation targets.
3. Header/footer/hero/button/card design-system consolidation with desktop/mobile visual and interaction tests.
4. Page templates, service/equipment pages and semantic landmarks; remove unreachable code.
5. Article rendering/download and tool component extraction, route-effect cleanup; accessibility/keyboard tests.
6. Asset derivatives/loading and measured performance work; static content/build cleanup and final crawl.

No ranking or Core Web Vitals improvement is claimed from source inspection alone. Later batches must be based on the version the owner actually applies.
