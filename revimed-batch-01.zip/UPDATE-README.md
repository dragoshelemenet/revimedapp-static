# ReviMed — Batch 01

Start with `docs/refactor/batch-01/AUDIT.md`. The CHANGELOG in the same folder lists every change; VERIFICATION explains checks and remaining limitations.

Built against commit `721c7d66ee05b21bc4e7f4742386626952588381`. This is the first incremental update, not a finished whole-site refactor. No direct GitHub changes are required.

## Install in GitHub Codespaces

Upload `revimed-batch-01.zip` to your repository root. In a terminal at that root:

```bash
git pull --ff-only
REPO_DIR="$PWD"
UPDATE_DIR="$(mktemp -d /tmp/revimed-batch01-XXXXXX)"
unzip revimed-batch-01.zip -d "$UPDATE_DIR"
python3 "$UPDATE_DIR/APPLY-UPDATE.py" --repo "$REPO_DIR" --check
python3 "$UPDATE_DIR/APPLY-UPDATE.py" --repo "$REPO_DIR" --apply
npm ci
npm run build
npm run verify:batch-01
npx tsc --noEmit
git diff --check
git diff --stat
python3 -m http.server 3000 --directory out
```

The installer preserves repository-relative paths and removes the three obsolete sitemap/robots source files. Do not unzip directly over your repository: extraction alone cannot apply deletions. It validates every affected original and new file before writing, refuses local conflicts, backs up originals outside the repository, and prints the backup path. It never commits or pushes. If any command fails, stop and inspect its error before continuing. Do not use force/reset to bypass a mismatch.

Use Node compatible with locked Next 16 (at least Node 20.9; validation here used Node 24.22.1). `npm ci` keeps dependency versions from the existing lockfile. Git pull is for obtaining your latest repository changes, not for obtaining this ZIP update.

Open forwarded port 3000. Perform the visual/interaction checks in VERIFICATION.md. Publish only the complete `out` produced by **npm run build**; that command now generates sitemap.xml and robots.txt after Next finishes. Do not use next start for this static export.

After your review, commit the installed changes yourself. Avoid including the uploaded ZIP, out, node_modules or build output in the commit. The package-only installer/manifest/README stay in the temporary extraction directory.

## Rollback before committing

Keep the printed backup path. While the extracted package is still available:

```bash
python3 "$UPDATE_DIR/APPLY-UPDATE.py" --repo "$REPO_DIR" --rollback /tmp/PASTE-THE-PRINTED-BACKUP-DIRECTORY
npm run build
```

Rollback restores original files and removes added files, but refuses if you edited affected files after installation. Temporary backups do not survive Codespace deletion/rebuild; commit reviewed changes or retain the backup if needed. Rollback does not alter git history.

## Included / excluded

Includes modified/new source at original paths, audit of all 129 tracked files, changelog, verification and installation support. The manifest records three deletions: app/sitemap.ts, public/sitemap.xml, public/robots.txt. No dependencies, images, database, build artifacts or entire repository copy are bundled.
