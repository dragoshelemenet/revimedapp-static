import Link from 'next/link';
import { getLocalizedEquipmentItems } from '@/lib/equipmentLocalized';
import { equipmentGroup } from '@/lib/equipmentPatient';
import { investigations, investigationSlugs } from '@/lib/investigations';
import { langPrefix, type SiteLang } from '@/lib/equipment';
export function RelatedPatientPages({slug,lang}:{slug:string;lang:SiteLang}) {
 const prefix=langPrefix(lang); const ru=lang==='ru';
 const selected=getLocalizedEquipmentItems(lang).filter(i=>{
  const g=equipmentGroup(i.slug);
  return slug==='diagnostic-functional'?['amp','rheo'].includes(g):slug==='electroterapie'?['cranial','amplipuls','ionto'].includes(g):slug==='terapie-balneara'?g==='detox':slug==='fizioterapie-si-reabilitare'?['heat','massage'].includes(g):false;
 });
 if(!selected.length)return null;
 return <section className="relatedPatientPages"><h2>{ru?'Процедуры и оборудование':lang==='ro'?'Proceduri și echipamente':lang==='ua'?'Процедури та обладнання':'Procedures and equipment'}</h2><ul>{slug==='diagnostic-functional'&&(lang==='ro'||lang==='ru')&&investigationSlugs.map(s=><li key={s}><Link href={`${prefix}/investigatii/${s}/`}>{investigations[s][lang].title}</Link></li>)}{selected.map(i=><li key={i.slug}><Link href={`${prefix}/utilaj/${i.slug}/`}>{i.title}</Link></li>)}</ul></section>;
}
