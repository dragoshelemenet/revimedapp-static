import { equipmentPatient } from "@/lib/equipmentPatient";
import { getLocalizedService } from "@/lib/servicesLocalized";
import { PatientActions, ClinicPhoto } from "./PatientActions";
import { JsonLd, breadcrumbJsonLd } from "@/lib/seo";
import Link from "next/link";
import {
  equipmentText,
  langPrefix,
  normalizeLang,
} from "@/lib/equipment";
import {
  getLocalizedEquipmentItem,
  getLocalizedEquipmentItems,
} from "@/lib/equipmentLocalized";

export function EquipmentListPage({ lang = "ro" }: { lang?: string }) {
  const safeLang = normalizeLang(lang);
  const t = equipmentText[safeLang];
  const prefix = langPrefix(safeLang);
  const items = getLocalizedEquipmentItems(safeLang);

  return (
    <main lang={safeLang === "ua" ? "uk" : safeLang}>
      <section className="pageHero equipmentHero">
        <div className="rmShell">
          <p className="breadcrumbs">{t.home} / {t.nav}</p>
          <h1>{t.title}</h1>
          <p>{t.subtitle}</p>
        </div>
      </section>

      <section className="rmSection equipmentSection">
        <div className="rmShell">
          <div className="equipmentGrid">
            {items.map((item) => (
              <Link className="equipmentCard" href={`${prefix}/utilaj/${item.slug}`} key={item.slug}>
                <span className="equipmentBadge">{item.category}</span>
                <h2>{item.title}</h2>
                <p>{equipmentPatient(item, safeLang)?.heading || item.short}</p>
                <b>{t.open} →</b>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}

export function EquipmentDetailPage({ lang = "ro", slug }: { lang?: string; slug: string }) {
  const safeLang = normalizeLang(lang);
  const t = equipmentText[safeLang];
  const prefix = langPrefix(safeLang);
  const item = getLocalizedEquipmentItem(safeLang, slug);

  if (!item) return null;
  const patient = equipmentPatient(item, safeLang);
  const related = patient && getLocalizedService(safeLang, patient.service);
  const ru = safeLang === "ru";

  return (
    <main lang={safeLang === "ua" ? "uk" : safeLang}>
      <section className="pageHero equipmentHero">
        <div className="rmShell">
          <nav className="breadcrumbs" aria-label={ru ? "Навигация" : "Breadcrumbs"}><Link href={`${prefix}/`}>{t.home}</Link> / <Link href={`${prefix}/utilaj/`}>{t.nav}</Link> / {item.title}</nav>
          <h1>{item.title}{safeLang === "ro" ? " în Chișinău" : ru ? " в Кишинёве" : ""}</h1>
          <p>{equipmentPatient(item, safeLang)?.heading || item.short}</p>
        </div>
      </section>

      <section className="rmSection equipmentDetailSection">
        <div className="rmShell">
          <article className="equipmentDetailCard">
            <span className="equipmentBadge">{item.category}</span>
            <h2>{item.title}</h2>
            <p className="equipmentLead">{patient?.heading || item.short}</p>
            <ClinicPhoto lang={safeLang}/>
            {patient && <p>{ru ? `В каталоге Revimed PLUS+ указано название «${item.title}». Перед записью уточните точную модель и доступность процедуры; перечень оборудования не заменяет индивидуальное назначение.` : `Catalogul Revimed PLUS+ menționează denumirea „${item.title}”. Înainte de programare, confirmați modelul exact și disponibilitatea procedurii; lista de echipamente nu înlocuiește indicația individuală.`}</p>}

            {(patient?.sections || item.sections).map((section) => (
              <section className="equipmentInfoBox" key={section.title}>
                <h2>{section.title}</h2>
                {section.body.length > 1 ? (
                  <ul>
                    {section.body.map((line) => <li key={line}>{line}</li>)}
                  </ul>
                ) : (
                  <p>{section.body[0]}</p>
                )}
              </section>
            ))}

            {patient && <section className="patientFaq"><h2>{ru ? "Вопросы перед записью" : "Întrebări înainte de programare"}</h2>{patient.faq.map(f => <details key={f.q}><summary>{f.q}</summary><p>{f.a}</p></details>)}</section>}
            {related && <p><Link href={`${prefix}/servicii/${related.slug}/`}>{related.title} →</Link></p>}
            {patient && patient.sources.length > 0 && <section className="patientSources"><h2>{ru ? "Источники и ограничения" : "Surse și limite"}</h2><p>{ru ? "Общая информация о методе; источники не подтверждают эффективность или характеристики каждой модели в каталоге." : "Informații generale despre metodă; sursele nu confirmă eficacitatea sau specificațiile fiecărui model din catalog."}</p><ul>{patient.sources.map(url => <li key={url}><a href={url} rel="noreferrer">{new URL(url).hostname} — {url.split('/').filter(Boolean).pop()}</a></li>)}</ul></section>}
            <PatientActions lang={safeLang}/>
            <JsonLd data={breadcrumbJsonLd([{name:t.home,path:`${prefix}/`},{name:t.nav,path:`${prefix}/utilaj/`},{name:item.title,path:`${prefix}/utilaj/${slug}/`}])}/>
            <p className="equipmentNote">⚠️ {t.note}</p>

            <Link className="rmBtn light" href={`${prefix}/utilaj`}>
              ← {t.back}
            </Link>
          </article>
        </div>
      </section>
    </main>
  );
}
