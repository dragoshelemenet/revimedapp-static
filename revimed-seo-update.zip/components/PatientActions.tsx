import Link from 'next/link';
import { langPrefix, type SiteLang } from '@/lib/equipment';
import { dictionary } from '@/lib/i18n';
export function PatientActions({lang}: {lang: SiteLang}) {
 const t = dictionary[lang]; const prefix = langPrefix(lang);
 return <aside className="patientActions">
  <h2>{lang === 'ru' ? 'Запись в Revimed PLUS+, Кишинёв' : lang === 'ro' ? 'Programare la Revimed PLUS+, Chișinău' : t.appointment}</h2>
  <p>Str. Mircea cel Bătrân 13/2 · Ciocana</p>
  <div className="patientLinks"><a className="rmBtn" href="tel:+37322605060">{t.callNow}: 022 60 50 60</a><Link className="rmBtn light" href={`${prefix}/preturi/`}>{t.prices}</Link><Link href={`${prefix}/contact/`}>{t.contact}</Link></div>
 </aside>;
}
export function ClinicPhoto({lang}: {lang: SiteLang}) {
 const caption = lang === 'ru' ? 'Помещение центра из существующей галереи Revimed; не фотография конкретной модели аппарата.' : lang === 'ro' ? 'Spațiu din galeria existentă Revimed; fotografia nu reprezintă un anumit model de aparat.' : lang === 'ua' ? 'Приміщення з галереї Revimed; не фотографія конкретної моделі апарата.' : 'Room from the existing Revimed gallery; not a photograph of a specific device model.';
 return <figure className="patientPhoto"><img src="/images/revimed-cabinet-proceduri-960.webp" srcSet="/images/revimed-cabinet-proceduri-480.webp 480w, /images/revimed-cabinet-proceduri-960.webp 960w" sizes="(max-width: 720px) 92vw, 700px" width="960" height="720" loading="lazy" decoding="async" alt={caption}/><figcaption>{caption}</figcaption></figure>;
}
