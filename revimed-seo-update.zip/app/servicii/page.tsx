import { patientMetadata } from "@/lib/patientSeo";
import type { Metadata } from "next";
import { ServicesListPage } from "@/components/ServicesPages";
import { servicesText } from "@/lib/services";

export const metadata: Metadata = patientMetadata(servicesText.ro.title + " în Chișinău", servicesText.ro.subtitle, "/servicii", "ro");

export default function Page() {
  return <ServicesListPage lang="ro" />;
}
