import type { MetadataRoute } from 'next';
import { equipmentItems } from '@/lib/equipment';
import { servicesRo } from '@/lib/services';
import { staticBlogPosts } from '@/lib/staticBlogPosts';
import { investigationSlugs } from '@/lib/investigations';
import { siteUrl } from '@/lib/seo';
export const dynamic = 'force-static';
// Core routes are available during export. postbuild reconciles this with actual HTML,
// including application routes, and excludes noncanonical aliases and noindex pages.
export default function sitemap():MetadataRoute.Sitemap {
 const paths=new Set<string>();
 for(const lang of ['','/ru','/en','/ua']) {
  for(const p of ['','/servicii','/utilaj','/contact','/preturi','/despre-noi','/galerie','/blog','/aplicatii'])paths.add(`${lang}${p}/`);
  for(const item of equipmentItems)paths.add(`${lang}/utilaj/${item.slug}/`);
  for(const item of servicesRo)paths.add(`${lang}/servicii/${item.slug}/`);
 }
 for(const p of staticBlogPosts.filter(p=>p.published)) paths.add(`${p.lang==='ro'?'':`/${p.lang}`}/blog/${p.slug}/`);
 for(const lang of ['','/ru'])for(const slug of investigationSlugs)paths.add(`${lang}/investigatii/${slug}/`);
 return [...paths].sort().map(p=>({url:siteUrl+p}));
}
