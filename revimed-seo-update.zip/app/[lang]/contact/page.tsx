import { makeAdvancedMetadata, pageSeoText } from "@/lib/seoAdvanced";
import { notFound } from "next/navigation";
import { ContactTemplate } from "@/lib/pageTemplates";
import { isLang, type Lang } from "@/lib/i18n";
export const dynamicParams = false;

const staticLangs = ["en", "ru", "ua"];

export function generateStaticParams() {
  return staticLangs.map((lang) => ({ lang }));
}


export const dynamic = "force-static";
export default async function Page({ params }: { params: Promise<{ lang: string }> }) {
 const { lang } = await params;
 if (!isLang(lang) || lang === "ro") notFound();
 return <ContactTemplate lang={lang as Lang} />;
}

export async function generateMetadata({ params }: { params: Promise<{lang:string}> }) {
 const {lang} = await params;
 if (!isLang(lang)) return {};
 const c = pageSeoText[lang]["contact"];
 if (!c) return {};
 return makeAdvancedMetadata({lang,path:"/contact",title:c.title,description:c.description});
}
