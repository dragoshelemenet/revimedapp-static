import { patientMetadata } from "@/lib/patientSeo";
import type { Metadata } from "next";
import { ServicesListPage } from "@/components/ServicesPages";
import { normalizeLang, servicesText } from "@/lib/services";
export const dynamicParams = false;

const staticLangs = ["en", "ru", "ua"];

export function generateStaticParams() {
  return staticLangs.map((lang) => ({ lang }));
}



type Props = { params: Promise<{ lang: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { lang } = await params;
  const safeLang = normalizeLang(lang);
  return patientMetadata(servicesText[safeLang].title + (safeLang === "ru" ? " в Кишинёве" : " — Chișinău"), servicesText[safeLang].subtitle, "/servicii", safeLang);
}

export default async function Page({ params }: Props) {
  const { lang } = await params;
  return <ServicesListPage lang={lang} />;
}
