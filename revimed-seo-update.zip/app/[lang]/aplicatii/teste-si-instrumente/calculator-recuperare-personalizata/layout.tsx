import { toolMetadata } from "@/lib/toolSeo";
export async function generateMetadata({params}:{params:Promise<{lang:string}>}){const {lang}=await params;return toolMetadata("calculator-recuperare-personalizata",lang);}
export default function Layout({children}:{children:React.ReactNode}){return <>{children}</>;}
