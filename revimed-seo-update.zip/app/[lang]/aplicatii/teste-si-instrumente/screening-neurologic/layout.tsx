import { toolMetadata } from "@/lib/toolSeo";
export async function generateMetadata({params}:{params:Promise<{lang:string}>}){const {lang}=await params;return toolMetadata("screening-neurologic",lang);}
export default function Layout({children}:{children:React.ReactNode}){return <>{children}</>;}
