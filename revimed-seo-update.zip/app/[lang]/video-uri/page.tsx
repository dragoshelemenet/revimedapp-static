import { notFound } from 'next/navigation';
import { isLang } from '@/lib/i18n';
import { GalleryTemplate } from '@/lib/pageTemplates';
import { patientMetadata } from '@/lib/patientSeo';
export const dynamicParams=false;
export function generateStaticParams(){return ['en','ru','ua'].map(lang=>({lang}));}
export async function generateMetadata({params}:{params:Promise<{lang:string}>}){const {lang}=await params;if(!isLang(lang))return {};return patientMetadata(lang==='ru'?'Галерея и видео':lang==='ua'?'Галерея та відео':'Gallery and videos','Revimed PLUS+ — Chișinău','/galerie',lang);}
export default async function Page({params}:{params:Promise<{lang:string}>}){const {lang}=await params;if(!isLang(lang)||lang==='ro')notFound();return <GalleryTemplate lang={lang}/>;}
