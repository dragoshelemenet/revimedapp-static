import { dictionary } from "@/lib/i18n";
import { makeAdvancedMetadata, pageSeoText } from "@/lib/seoAdvanced";
import { notFound } from "next/navigation";
import { AboutTemplate } from "@/lib/pageTemplates";
import { isLang, type Lang } from "@/lib/i18n";
export const dynamicParams = false;

const staticLangs = ["en", "ru", "ua"];

export function generateStaticParams() {
  return staticLangs.map((lang) => ({ lang }));
}


export const dynamic = "force-static";
export default async function Page({ params }: { params: Promise<{ lang: string }> }) {
 const { lang } = await params;
 if (!isLang(lang) || lang === "ro") notFound();
 return <AboutTemplate lang={lang as Lang} />;
}

export async function generateMetadata({ params }: { params: Promise<{lang:string}> }) {
 const {lang} = await params;
 if (!isLang(lang)) return {};
 const c = pageSeoText[lang]["about"];
 if (!c) return makeAdvancedMetadata({lang,path:"/despre-noi",title:dictionary[lang].about,description:dictionary[lang].about + " — Revimed PLUS+, Chișinău"});
 return makeAdvancedMetadata({lang,path:"/despre-noi",title:c.title,description:c.description});
}
