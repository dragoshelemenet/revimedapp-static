import { patientMetadata } from "@/lib/patientSeo";
import type { Metadata } from "next";
import { EquipmentListPage } from "@/components/EquipmentPages";
import { equipmentText } from "@/lib/equipment";

export const metadata: Metadata = patientMetadata(equipmentText.ro.title + " în Chișinău", equipmentText.ro.subtitle, "/utilaj", "ro");

export default function Page() {
  return <EquipmentListPage lang="ro" />;
}
