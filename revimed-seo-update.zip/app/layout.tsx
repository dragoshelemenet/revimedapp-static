import type { Metadata } from "next";
import "../styles/global.css";
import { JsonLd, clinicJsonLd, websiteJsonLd } from "@/lib/seo";
import Header from "../components/Header";
import Footer from "../components/Footer";
import LanguageFlagOverlay from "../components/LanguageFlagOverlay";
import RouteTransition from "../components/RouteTransition";
import MobileCallBar from "../components/MobileCallBar";
import { site } from "../lib/site";
import "../lib/seedLanguages";

import BlogArticleEnhancer from "@/components/BlogArticleEnhancer";
import HeroBottomScrollHint from "@/components/HeroBottomScrollHint";
export const metadata: Metadata = {
 metadataBase: new URL(site.url),
 title: {
  default: site.name,
  template: `%s | ${site.shortName}`
 },
 description: site.description,
 keywords: [
  "Revimed",
  "centru medical Chișinău",
  "neurolog Chișinău",
  "neurochirurg Chișinău",
  "fizioterapie Chișinău",
  "reabilitare medicală Chișinău"
 ],
 openGraph: {
  type: "website",
  locale: "ro_MD",
  url: site.url,
  siteName: site.name,
  title: site.name,
  description: site.description,
  images: [{ url: site.image, width: 1200, height: 630, alt: site.name }]
 },
 twitter: {
  card: "summary_large_image",
  title: site.name,
  description: site.description,
  images: [site.image]
 },
 icons: {
  icon: "/favicon.svg",
  shortcut: "/favicon.svg",
  apple: "/favicon.svg"
 },
 robots: {
  index: true,
  follow: true,
  googleBot: {
   index: true,
   follow: true,
   "max-image-preview": "large",
   "max-snippet": -1,
   "max-video-preview": -1
  }
 }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {

 return (
  <html lang="ro" suppressHydrationWarning>
   <body>
    <RouteTransition />
    <Header />
    <LanguageFlagOverlay />
    <div id="site-content"><JsonLd data={clinicJsonLd("ro")} />
    <JsonLd data={websiteJsonLd()} />
    {children}</div>
    <Footer />
    <MobileCallBar />
           <BlogArticleEnhancer />
                          <HeroBottomScrollHint />
      </body>
  </html>
 );
}