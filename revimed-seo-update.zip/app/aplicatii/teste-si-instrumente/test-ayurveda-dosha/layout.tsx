import { toolMetadata } from "@/lib/toolSeo";
export const metadata=toolMetadata("test-ayurveda-dosha","ro");
export default function Layout({children}:{children:React.ReactNode}){return <>{children}</>;}
