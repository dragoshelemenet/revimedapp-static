import { toolMetadata } from "@/lib/toolSeo";
export const metadata=toolMetadata("revimed-yoga-tibetan","ro");
export default function Layout({children}:{children:React.ReactNode}){return <>{children}</>;}
