import { toolMetadata } from "@/lib/toolSeo";
export const metadata=toolMetadata("calculator-recuperare-personalizata","ro");
export default function Layout({children}:{children:React.ReactNode}){return <>{children}</>;}
