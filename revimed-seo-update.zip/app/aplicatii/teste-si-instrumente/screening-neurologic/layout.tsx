import { toolMetadata } from "@/lib/toolSeo";
export const metadata=toolMetadata("screening-neurologic","ro");
export default function Layout({children}:{children:React.ReactNode}){return <>{children}</>;}
