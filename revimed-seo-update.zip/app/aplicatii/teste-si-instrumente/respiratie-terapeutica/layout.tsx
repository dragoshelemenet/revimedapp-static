import { toolMetadata } from "@/lib/toolSeo";
export const metadata=toolMetadata("respiratie-terapeutica","ro");
export default function Layout({children}:{children:React.ReactNode}){return <>{children}</>;}
