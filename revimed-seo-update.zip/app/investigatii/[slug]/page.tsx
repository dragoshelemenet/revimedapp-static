import { notFound } from 'next/navigation';
import { investigations, investigationSlugs, type InvestigationSlug } from '@/lib/investigations';
import { InvestigationPage } from '@/components/InvestigationPage';
import { investigationMetadata } from '@/lib/patientSeo';
export const dynamicParams = false;
export function generateStaticParams(){return investigationSlugs.map(slug=>({slug}));}
export async function generateMetadata({params}:{params:Promise<{slug:string}>}){const {slug}=await params;return investigationMetadata(slug,'ro');}
export default async function Page({params}:{params:Promise<{slug:string}>}){const {slug}=await params;if(!Object.hasOwn(investigations,slug)) notFound();return <InvestigationPage slug={slug as InvestigationSlug} lang="ro"/>;}
