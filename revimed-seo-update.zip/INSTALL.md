# Install in GitHub Codespaces

The ZIP is a source update, not a full repository or deployment. It was built against main commit `837b6f53a840b34f250a2ef107684571cf0a4a8e`. Existing URLs and unrelated files are retained. No secrets, database, node_modules, .git, caches or generated out/ directory are included.

## 1. Update your checkout

Open the repository root in the Codespaces terminal. Review local changes first; save/commit your own work before pulling if needed.

```bash
git status --short
git pull --ff-only
```

Upload `revimed-seo-update.zip` into the repository root using Codespaces Explorer. Then run:

```bash
unzip -q revimed-seo-update.zip -d ../revimed-seo-update
python3 ../revimed-seo-update/apply-seo-update.py --repo "$PWD"
python3 ../revimed-seo-update/apply-seo-update.py --repo "$PWD" --apply
```

Use a fresh `../revimed-seo-update` extraction directory. The first Python command only checks files. The second creates a timestamped backup beside the repository and copies only manifest-listed files. It never deletes files, commits or pushes. It stops before copying if a target file differs from the audited base (or the already-applied update), protecting newer work. If it reports conflicts, merge those specific files; do not run `unzip -o` over the checkout.

## 2. Confirm the domain and build

The current source defaults to `https://revimed.site`. Confirm that this is the public production domain. If another domain is correct, export that actual URL as `NEXT_PUBLIC_SITE_URL` before building; do not use a Codespaces preview URL as the production canonical.

```bash
npm ci
npm run build
npm run check:seo
```

Use Node.js 20.9+ (the Next.js version is pinned by the existing lockfile). The tested environment used Next.js 16.2.6. No dependency versions were changed. The native `better-sqlite3` dependency requires a supported Node installation; standard Codespaces includes build tools if its prebuilt binary is unavailable.

**Always use `npm run build`.** Its `postbuild` step writes correct HTML languages, reconciles the sitemap with exported pages and writes robots.txt. Running `next build` alone skips that step. Deploy the resulting `out/` directory using your existing static hosting process.

The existing application may update its SQLite file while building. That behavior predates this ZIP; no database file is installed or staged by this update.

## 3. Preview locally

```bash
python3 -m http.server 3000 --directory out
```

Open port 3000 in Codespaces. Check:

- `/utilaj/aparat-electroforeza-medicamentoasa/`
- `/ru/utilaj/aparat-electroforeza-medicamentoasa/`
- `/investigatii/electroencefalograma-eeg/`
- `/ru/investigatii/electrocardiograma-ecg/`
- `/investigatii/ecografie-organe-interne/`
- `/servicii/diagnostic-functional/`
- `/preturi/` (open and close categories)
- `/sitemap.xml` and `/robots.txt`

Check at a phone width as well as desktop, and review clinic/model details flagged in CHANGELOG.md. Stop the preview with Ctrl+C.

## 4. Review, commit and push when satisfied

```bash
git diff --stat
git diff --check
python3 ../revimed-seo-update/apply-seo-update.py --repo "$PWD" --stage
git diff --cached --stat
git commit -m "Improve Revimed local SEO and patient equipment guides"
git push
```

The staging helper adds only files listed in this package, excluding the uploaded ZIP, build-generated SQLite changes and unrelated work. It does not unstage files you had already staged; inspect `git diff --cached` before committing. The assistant has not run these commit/push commands.

## Backup and recovery

The installer prints the backup ZIP path. It contains original versions of overwritten files plus `NEW_FILES.txt` listing newly added paths. To undo, restore the original files from that backup and review the new-file list manually. There is no automatic deletion step. Keep the backup until the update is reviewed and deployed successfully.

## Verification limits

Static build and automated local-route/image/canonical/JSON-LD checks were performed. Browser verification covered a Russian equipment page and FAQ interaction; further browser navigation hit an automatic approval usage-limit error. Device emulation was unavailable. Field Core Web Vitals, real Google indexing, exact device photo rights and clinical approval are not claimed as completed.
