#!/usr/bin/env python3
"""Apply only the ZIP's listed files. Never delete files or commit/push."""
import argparse, datetime, hashlib, json, pathlib, shutil, subprocess, sys, zipfile
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--repo',required=True,type=pathlib.Path)
g=p.add_mutually_exclusive_group();g.add_argument('--apply',action='store_true');g.add_argument('--stage',action='store_true')
a=p.parse_args();root=a.repo.resolve();source=pathlib.Path(__file__).resolve().parent
manifest=json.loads((source/'UPDATE_MANIFEST.json').read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def safe(base,name):
 rel=pathlib.PurePosixPath(name)
 if rel.is_absolute() or '..' in rel.parts:raise SystemExit('Unsafe package path: '+name)
 out=base.joinpath(*rel.parts)
 if not out.resolve().is_relative_to(base):raise SystemExit('Path escapes target: '+name)
 return out
if not (root/'package.json').is_file():raise SystemExit('Target is not the repository root (package.json missing).')
if a.stage:
 for entry in manifest['files']:
  dest=safe(root,entry['path'])
  if not dest.is_file() or digest(dest)!=entry['updated_sha256']:raise SystemExit('Cannot stage: changed/missing '+entry['path'])
 subprocess.run(['git','-C',str(root),'add','--',*[x['path'] for x in manifest['files']]],check=True)
 print('Staged only update files. Review git diff --cached before committing.');sys.exit(0)
conflicts=[];todo=[]
for entry in manifest['files']:
 name=entry['path'];src=safe(source,name);dst=safe(root,name)
 if not src.is_file() or digest(src)!=entry['updated_sha256']:raise SystemExit('Package integrity error: '+name)
 if dst.exists():
  if not dst.is_file():conflicts.append(name+' (not a regular file)');continue
  current=digest(dst)
  if current==entry['updated_sha256']:continue
  if current!=entry['base_sha256']:conflicts.append(name+' (differs from audited base)');continue
 elif entry['base_sha256'] is not None:conflicts.append(name+' (base file missing)');continue
 todo.append((name,src,dst))
if conflicts:
 print('Nothing copied. Resolve these conflicts manually; do not blindly unzip over them:\n'+'\n'.join(conflicts));sys.exit(2)
print(f'Validated {len(manifest["files"])} package files; {len(todo)} files to copy. No files will be deleted.')
if not a.apply:
 print('Dry run only. Add --apply to install.');sys.exit(0)
if not todo:print('Update already applied.');sys.exit(0)
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
backup=root.parent/('revimed-seo-backup-'+stamp+'.zip')
created=[]
with zipfile.ZipFile(backup,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for name,src,dst in todo:
  if dst.exists():z.write(dst,name)
  else:created.append(name)
 z.writestr('NEW_FILES.txt','\n'.join(created)+'\n')
for name,src,dst in todo:
 dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
print('Applied. Backup:',backup)
print('Next: npm ci && npm run build && npm run check:seo')
