# Revimed PLUS+ — local SEO implementation report

Research and implementation date: 11 November 2026. Base commit: `837b6f53a840b34f250a2ef107684571cf0a4a8e`.

## Scope and evidence

The audit covers active Next.js routes, components, localized catalogs, metadata helpers, CSS, static blog data, application registry and the checked-in SQLite content. The source scan initially covered 103 text/source files. SQLite inspection found 101 Romanian price rows, six service records and 25 catalog devices. These are mentions in the repository, not independent proof of current availability or clinical validity. Historical ZIPs and CSS backups are not treated as current public content.

The full device list and all price-row names are in [CONTENT_INVENTORY.md](audit/CONTENT_INVENTORY.md). [EQUIPMENT_AND_PROCEDURES.csv](audit/EQUIPMENT_AND_PROCEDURES.csv) maps each record's source, existing URL, landing-page decision, images, patient questions, links and evidence gaps. BEMER is a legacy source mention, not newly promoted as a confirmed current service.

## Search intent: verified observations versus editorial estimates

No Search Console, Keyword Planner or paid keyword-volume dataset was available. No search volume, ranking position, traffic estimate or ranking guarantee is asserted. Observed local provider terminology verifies that these procedure names appear in Chișinău search results; the proposed query clusters below are editorial targeting hypotheses, not measured queries.

| Cluster | Romanian query candidates | Russian query candidates | Destination |
|---|---|---|---|
| EEG | EEG Chișinău; electroencefalogramă preț; pregătire EEG; unde se face EEG | ЭЭГ Кишинёв; электроэнцефалограмма цена; подготовка к ЭЭГ | `/investigatii/electroencefalograma-eeg/` and `/ru/…` |
| ECG | ECG Chișinău; electrocardiogramă preț; ECG interpretare | ЭКГ Кишинёв; кардиограмма цена; расшифровка ЭКГ | `/investigatii/electrocardiograma-ecg/` and `/ru/…` |
| Ultrasound | ecografie organe interne Chișinău; pregătire ecografie; ecografie preț Moldova | УЗИ внутренних органов Кишинёв; подготовка к УЗИ; УЗИ цена | `/investigatii/ecografie-organe-interne/` and `/ru/…` |
| Drug iontophoresis | electroforeză medicamentoasă Chișinău; ionoforeză doare; electroforeză preț | электрофорез Кишинёв; лекарственный электрофорез цена; боль при электрофорезе | existing drug-electrophoresis equipment page |
| Electrical therapy | amplipuls Chișinău; electrostimulare contraindicații; electrosomn | амплипульс Кишинёв; электросон цена; противопоказания электротерапии | existing equipment pages + electrotherapy hub |
| Rehabilitation | fizioterapie Ciocana; recuperare medicală Chișinău; masaj terapeutic | физиотерапия Кишинёв; реабилитация Чеканы; лечебный массаж | existing rehabilitation service |
| Equipment-name lookup | RHEOTEST; AMP Biopromin; Transair; LENAR; MDM + Moldova | реография; АМП; Трансаир; ЛЭНАР; МДМ + Кишинёв | existing equipment catalog; exact model confirmation required |
| Wellness evidence | baie ionică elimină toxine; detox picioare dovezi | ионная ванна токсины; детокс стоп доказательства | existing DETOX pages; no medical detox promise |

Local sources consulted for terminology and appointment intent, not clinical evidence and not Revimed pricing:

- [Neurogen services](https://www.neurogen.md/site/ro/servicii): EEG, ECG and echoencephalography terminology.
- [SANCOS Russian price list](https://www.sancos.md/ru/lista-de-preturi): ЭЭГ and лекарственный электрофорез.
- [Constructorul price list](https://constructorul.md/preturi/servicii): electroforeză, amplipulsterapie and somnul electrogen.
- [Atletmed rehabilitation](https://atletmed.md/sectia-reabilitare-medicala/): procedure-family terminology.

## Patient discussion research

Small qualitative sample, not a representative survey or a claim about frequency across Moldova. Public Romanian/Russian local-community evidence was insufficient for a reliable local forum trend. Local provider pages establish terminology only. Public Reddit discussions supplied question ideas; none supplied clinical evidence or testimonials for Revimed.

| Public discussion | Information gap | Implementation |
|---|---|---|
| [Iontophoresis not working, painful process](https://www.reddit.com/r/Hyperhidrosis/comments/1hnra3l) | Discomfort and self-escalation of current | Explain reporting pain/burning; avoid self-adjusted protocols. Hyperhidrosis treatment is not asserted as a Revimed service. |
| [First EEG, more unpleasant than expected](https://www.reddit.com/r/Epilepsy/comments/1r64g24/first_eeg_way_more_unpleasant_than_expected/) | What happens during EEG, light stimulation, anxiety | Explain recording versus stimulation, preparation and telling staff about symptoms. |
| [First EEG appointment](https://www.reddit.com/r/Epilepsy/comments/1tq6pha/first_eeg_appointment/) | Meaning of a normal result | Explain interpretation in clinical context; no automatic exclusion of epilepsy. |
| [What do you think about ionic foot detox?](https://www.reddit.com/r/30PlusSkinCare/comments/16n6o3o/what_do_you_think_about_the_ionic_foot_detox/) | Whether water color proves toxin removal | Evidence-limited detox FAQ; no diagnosis from water color. |
| [Has anyone tried ionic foot detox baths?](https://www.reddit.com/r/covidlonghaulers/comments/1h7rhvh) | Claimed benefits versus evidence | Separate relaxation from unsupported detoxification claims. |

No forum quotations were copied. The site does not promote forum anecdotes as treatment results.

## Medical sourcing and boundaries

- EEG: [NHS overview](https://www.nhs.uk/tests-and-treatments/electroencephalogram/), [Hull University Teaching Hospitals](https://www.hey.nhs.uk/patient-leaflet/electroencephalogram-eeg-adults/), [Kingston and Richmond](https://www.kingstonandrichmond.nhs.uk/patients-and-families/patient-leaflets/electroencephalogram-eeg). Preparation, recording process and aftercare; clinic-specific timing remains unconfirmed.
- ECG: [NHS](https://www.nhs.uk/tests-and-treatments/electrocardiogram/), [MedlinePlus](https://www.medlineplus.gov/lab-tests/electrocardiogram/), [NHLBI](https://www.nhlbi.nih.gov/health/heart-tests). Electrical recording and limits; no Holter or stress-test availability inferred.
- Ultrasound: [NHS](https://www.nhs.uk/tests-and-treatments/ultrasound-scan/), [NIBIB](https://www.nibib.nih.gov/science-education/science-topics/ultrasound), [ACR/RSNA patient information](https://www.radiologyinfo.org/en/info/abdominus). Diagnostic/therapeutic distinction and organ-specific preparation.
- Drug iontophoresis: [Cleveland Clinic](https://my.clevelandclinic.org/health/treatments/iontophoresis), [NCBI clinical review](https://www.ncbi.nlm.nih.gov/sites/books/NBK553090/). Medication transport, skin effects and clinician-selected protocol. No drug or dose prescribed.
- Electrical therapy: [NHS TENS](https://www.nhs.uk/tests-and-treatments/transcutaneous-electrical-nerve-stimulation-tens/). General electrical-stimulation safety context only; TENS evidence is not presented as proof for Amplipuls or cranial devices.
- Cranial stimulation: [2018 systematic review](https://pubmed.ncbi.nlm.nih.gov/29435567/) and [2023 review](https://pubmed.ncbi.nlm.nih.gov/37091717/). Evidence varies by condition/device; neither independently validates every Revimed-listed model. No universal indication list is inferred.
- Manufacturer documentation: [Transair archive manuals](https://www.tes.spb.ru/kontakts/77-tes/317-dlya-skachivaniya). Manuals are separately listed for 03/04/05. The repository's paired 01S/01P model labels remain unresolved; they are not declared equivalent. No reuse license for manufacturer photography was established.
- Ionic foot baths: [primary exploratory study](https://pubmed.ncbi.nlm.nih.gov/22174728/), [NCCIH detox overview](https://www.nccih.nih.gov/health/detoxes-and-cleanses-what-you-need-to-know). No toxin-removal promise. The study used IonCleanse, not the exact two catalog models; this distinction is preserved.
- Massage: [NCCIH](https://www.nccih.nih.gov/health/massage-therapy-what-you-need-to-know), [NCCIH pain guide](https://files.nccih.nih.gov/pain-ebook-2024-08-508.pdf). General safety, not proof of reflex-zone organ treatment or exact KDJ effects.
- Heat: [NHS Wales safety guidance](https://movebettergwent.nhs.wales/self_management/using-heat/). General precautions only; no lamp-specific settings invented.
- Rheography: [impedance plethysmography study](https://pmc.ncbi.nlm.nih.gov/articles/PMC2498042/). Supports the general measurement concept and limits, not validation of RHEOTEST or cerebrovascular screening claims.
- AMP: no sufficiently reliable model-specific independent validation was established. Studies on TensorTip were excluded as evidence for AMP because it is a different device.

This is researched educational copy, not a signed clinical review. No fabricated reviewer credentials, approval, success rates, contraindication completeness, regulatory status, clinical outcomes or testimonials were added. EN/UA legacy equipment text and the wider blog/app/price-list medical claims require separate clinician review.

## Architecture and linking

Keep all existing equipment URLs. Avoid city-keyword clone pages. New guides address distinct investigation intent, not alternate spellings of the same service. Romanian remains unprefixed; Russian uses `/ru/`; existing `/en/` and `/ua/` URLs are retained, with `uk` language tags for Ukrainian. New guides have only RO/RU alternates; EN/UA switches lead to the corresponding diagnostic service hub.

Service pages link to relevant equipment families; the diagnostic hub links all three guides. Every improved equipment page links back to its parent service, equipment catalog, contact and prices. Existing neurosurgery and Romanian-content blog aliases retain their URLs but canonicalize to their primary content. Localized video aliases canonicalize to gallery. No HTTP redirect is required for this package. On a future host migration, an optional 301 from the neurosurgery alias to the canonical is appropriate; do not use Next server redirects in this static project.

Many model variants still share family-level text because verified distinguishing details are unavailable. This is an explicitly unresolved content limitation. Do not invent specifications merely to make pages different. Add model manuals and authentic photos, then decide whether to consolidate genuinely equivalent variants.

## Images and licensing

| Output | Existing source | Use | Rights status |
|---|---|---|---|
| `revimed-cabinet-proceduri-{480,960}.webp` | `public/images/pre.jpg` | Visible equipment/guide photo, 4:3, responsive and lazy-loaded | Already supplied in repository; ownership/consent not independently established |
| `revimed-chisinau-receptie-{480,960}.webp` | `public/images/2pic.jpg` | Metadata sharing image / reception | Already supplied in repository; confirm rights |

Two source photographs were visually inspected. The cabinet image is explicitly captioned as a clinic-room image, not a model photograph. No external copyrighted photograph was downloaded; no stock image or generated picture is represented as the clinic's equipment. Exact equipment imagery remains outstanding. Existing unrelated external blog/icon assets are preserved and not newly licensed by this update.

WebP sizes: cabinet 480px 12,774 bytes / 960px 38,170 bytes; reception 480px 21,600 bytes / 960px 67,228 bytes. Explicit image aspect ratio, srcset/sizes and lazy loading reduce transfer and layout shift; this is not proof of a field Core Web Vitals pass.

## Technical verification and remaining work

`npm ci` dependencies were available and native SQLite was exercised; `npm run build` completed the production static export. `npm run check:seo` checks all exported index pages for local link/image targets, canonical count, Russian HTML language and JSON-LD syntax. It records warnings rather than hiding canonical alias title duplicates. See `audit/static-check.json` for the final run.

Browser checks completed: Russian equipment page rendered with its clinic image and the FAQ expanded successfully. A later browser navigation was blocked when automatic approval review hit a usage limit; Romanian guide and price-accordion browser checks were not completed. Layout review found and corrected long-heading clipping. Browser DevTools were restricted by the environment, so a mobile emulated-device session was not completed. Lighthouse/CrUX field measurements and full end-to-end testing of every pre-existing digital tool were not completed. Responsive CSS is implemented; these are explicit verification limits, not passes.

Remaining: confirm clinic details and device evidence, supply authentic model photos with rights, clinically review legacy translations/tools/marketing labels, verify the production domain and Google Business Profile, submit sitemap in Search Console, check real index coverage and local conversion tracking. No Search Console or Google Business Profile changes were made. Ranking improvement takes measurement after publication; this package does not claim rankings.

Final export: 243 HTML index files including error pages; 242 pages inspected by the static checker; 225 canonical sitemap entries. Zero checker errors. Remaining repeated-title warnings are listed in the JSON audit. ZIP integrity, dry-run installation, application, idempotent reapplication, conflict refusal and preservation of an unrelated sentinel file were tested against a separate archive of the base commit.
