import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve('out');
function walk(d){return fs.readdirSync(d,{withFileTypes:true}).flatMap(x=>x.isDirectory()?walk(path.join(d,x.name)):[path.join(d,x.name)]);}
const pages=walk(root).filter(p=>p.endsWith('/index.html')&&!p.includes('_not-found'));
const errors=[];const warnings=[];const titles=new Map();
for(const f of pages){
 const route='/'+path.relative(root,path.dirname(f)).replaceAll('\\','/')+'/';const s=fs.readFileSync(f,'utf8');
 for(const m of s.matchAll(/<(?:a|img|link)\b[^>]*(?:href|src)="([^"#]+)"[^>]*>/g)){
  const target=m[1].replaceAll('&amp;','&');if(!target.startsWith('/')||target.startsWith('//'))continue;
  const p=decodeURIComponent(target.split(/[?#]/)[0]);if(p.startsWith('/_next/'))continue;
  if(!(fs.existsSync(path.join(root,p))&&fs.statSync(path.join(root,p)).isFile())&&!fs.existsSync(path.join(root,p,'index.html')))errors.push(`${route}: missing ${p}`);
 }
 for(const m of s.matchAll(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/g)){try{JSON.parse(m[1]);}catch{errors.push(`${route}: invalid JSON-LD`);}}
 const canon=[...s.matchAll(/rel="canonical"/g)].length;if(canon!==1)errors.push(`${route}: canonical count ${canon}`);
 const h1=[...s.matchAll(/<h1[\s>]/g)].length;if(h1!==1)warnings.push(`${route}: H1 count ${h1}`);
 const t=s.match(/<title>(.*?)<\/title>/)?.[1];if(t){const a=titles.get(t)||[];a.push(route);titles.set(t,a);}
 if(route.startsWith('/ru/')&&!s.includes('<html lang="ru"'))errors.push(`${route}: incorrect Russian HTML lang`);
}
for(const [title,routes]of titles)if(routes.length>1)warnings.push(`Repeated title: ${title} (${routes.length} pages)`);
const result={pages:pages.length,errors:[...new Set(errors)],warnings};
fs.mkdirSync('audit',{recursive:true});fs.writeFileSync('audit/static-check.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));process.exitCode=errors.length?1:0;
