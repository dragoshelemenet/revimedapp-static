// Runs only after Next's static export. No server or runtime dependency.
import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve('out');
const origin = (process.env.NEXT_PUBLIC_SITE_URL || process.env.SITE_URL || 'https://revimed.site').replace(/\/$/,'');
const esc = s => s.replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;');
function walk(dir) { return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):[path.join(dir,e.name)]); }
const pages = walk(root).filter(p=>p.endsWith('/index.html'));
const records=[];
for(const file of pages){
 const route='/'+path.relative(root,path.dirname(file)).split(path.sep).filter(Boolean).join('/')+'/';
 const clean=route.replace(/\/+/g,'/');
 let html=fs.readFileSync(file,'utf8');
 const code=clean.split('/')[1]; const lang={ru:'ru',en:'en',ua:'uk'}[code] || 'ro';
 html=html.replace(/<html\b([^>]*)\blang="[^"]*"/,`<html$1lang="${lang}"`);
 // Existing route wrappers omit canonical metadata on some pages. Add only when absent.
 if(!/<link[^>]+rel="canonical"/.test(html)) html=html.replace('</head>',`<link rel="canonical" href="${esc(origin+clean)}"/></head>`);
 // Keep only existing translated URLs. Some old wrappers claim nonexistent variants.
 html=html.replace(/<link\b[^>]*rel="alternate"[^>]*>/g,tag=>{
  const href=tag.match(/href="([^"]+)"/)?.[1];if(!href)return tag;
  const url=new URL(href.replaceAll('&amp;','&'),origin);
  if(url.origin!==new URL(origin).origin)return tag;
  return fs.existsSync(path.join(root,decodeURIComponent(url.pathname),'index.html')) ? tag : '';
 });
 fs.writeFileSync(file,html);
 const canonical=html.match(/<link[^>]+rel="canonical"[^>]+href="([^"]+)"/)?.[1];
 if(/name="robots" content="[^"]*noindex/.test(html)||clean.includes('/_not-found/'))continue;
 // Omit aliases from the sitemap but preserve their exported HTML.
 if(canonical && new URL(canonical).pathname.replace(/\/$/,'')!==clean.replace(/\/$/,''))continue;
 const alternates=[...html.matchAll(/<link\b[^>]*rel="alternate"[^>]*>/g)].map(m=>{
  const l=m[0].match(/hrefLang="([^"]+)"/i)?.[1],h=m[0].match(/href="([^"]+)"/)?.[1];
  return l&&h?`<xhtml:link rel="alternate" hreflang="${esc(l)}" href="${h}"/>`:'';
 }).join('');
 records.push(`<url><loc>${esc(origin+clean)}</loc>${alternates}</url>`);
}
const xml=`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">\n${records.join('\n')}\n</urlset>\n`;
fs.writeFileSync(path.join(root,'sitemap.xml'),xml);
fs.writeFileSync(path.join(root,'robots.txt'),`User-agent: *\nAllow: /\nSitemap: ${origin}/sitemap.xml\n`);
console.log(`Static SEO: ${pages.length} HTML language attributes verified; ${records.length} canonical sitemap URLs.`);
