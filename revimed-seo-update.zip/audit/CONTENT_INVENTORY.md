# Existing medical content inventory

Source snapshot: main at 837b6f53a840b34f250a2ef107684571cf0a4a8e. The 101 Romanian price rows include duplicates and are not 101 distinct validated services. All rows and all 25 catalog records are preserved.

## Equipment catalog

| Equipment | Existing/improved Romanian URL | Russian URL |
|---|---|---|
| Aparat AMP | /utilaj/aparat-amp/ | /ru/utilaj/aparat-amp/ |
| Electrosomn-4T | /utilaj/electrosomn-4t/ | /ru/utilaj/electrosomn-4t/ |
| Electrosomn-5 / ES-10-5 | /utilaj/electrosomn-5-es-10-5/ | /ru/utilaj/electrosomn-5-es-10-5/ |
| Electrosomn-3 | /utilaj/electrosomn-3/ | /ru/utilaj/electrosomn-3/ |
| Etrans-1 | /utilaj/etrans-1/ | /ru/utilaj/etrans-1/ |
| Etrans-2 | /utilaj/etrans-2/ | /ru/utilaj/etrans-2/ |
| Etrans-3 | /utilaj/etrans-3/ | /ru/utilaj/etrans-3/ |
| Transair-01P / Transair-05 | /utilaj/transair-01p-transair-05/ | /ru/utilaj/transair-01p-transair-05/ |
| Transair-01S / Transair-04 | /utilaj/transair-01s-transair-04/ | /ru/utilaj/transair-01s-transair-04/ |
| Transair-01S / Transair-03 | /utilaj/transair-01s-transair-03/ | /ru/utilaj/transair-01s-transair-03/ |
| LENAR | /utilaj/lenar/ | /ru/utilaj/lenar/ |
| Bi-LENAR | /utilaj/bi-lenar/ | /ru/utilaj/bi-lenar/ |
| MDM-K | /utilaj/mdm-k/ | /ru/utilaj/mdm-k/ |
| MDM-101 | /utilaj/mdm-101/ | /ru/utilaj/mdm-101/ |
| MDM-2000 | /utilaj/mdm-2000/ | /ru/utilaj/mdm-2000/ |
| Amplipuls-4 | /utilaj/amplipuls-4/ | /ru/utilaj/amplipuls-4/ |
| Amplipuls-5 | /utilaj/amplipuls-5/ | /ru/utilaj/amplipuls-5/ |
| Amplipuls-6 | /utilaj/amplipuls-6/ | /ru/utilaj/amplipuls-6/ |
| Kandadzia / Kang Da Jia / LQX-2000A | /utilaj/kandadzia-kang-da-jia-lqx-2000a/ | /ru/utilaj/kandadzia-kang-da-jia-lqx-2000a/ |
| Aparat pentru electroforeză medicamentoasă | /utilaj/aparat-electroforeza-medicamentoasa/ | /ru/utilaj/aparat-electroforeza-medicamentoasa/ |
| Spectr-LC | /utilaj/spectr-lc/ | /ru/utilaj/spectr-lc/ |
| Lampă Solux | /utilaj/lampa-solux/ | /ru/utilaj/lampa-solux/ |
| DETOX Spa Bio | /utilaj/detox-spa-bio/ | /ru/utilaj/detox-spa-bio/ |
| SPA SY-F088 / DETOX BIO-178 | /utilaj/spa-sy-f088-detox-bio-178/ | /ru/utilaj/spa-sy-f088-detox-bio-178/ |
| RHEOTEST | /utilaj/rheotest/ | /ru/utilaj/rheotest/ |

## Procedure names in the price database

| Category | Existing wording |
|---|---|
| CONSULTAȚII DE SPECIALITATE | Consultație primară cu neurolog |
| CONSULTAȚII DE SPECIALITATE | Consultație repetată cu neurolog |
| CONSULTAȚII DE SPECIALITATE | Consultație primară cu neurochirurg |
| CONSULTAȚII DE SPECIALITATE | Consultație repetată cu neurochirurg |
| CONSULTAȚII DE SPECIALITATE | Consultație primară cu medic internist |
| CONSULTAȚII DE SPECIALITATE | Consultație repetată cu medic internist |
| CONSULTAȚII DE SPECIALITATE | Consultație primară cu medic fitoterapeut |
| CONSULTAȚII DE SPECIALITATE | Consultație primară cu reflexolog |
| CONSULTAȚII DE SPECIALITATE | Consultație repetată cu reflexolog |
| CONSULTAȚII DE SPECIALITATE | Consultație psihoterapeut |
| CONSULTAȚII DE SPECIALITATE | Consultație primară cu acupuncturist |
| CONSULTAȚII DE SPECIALITATE | Consultație repetată cu acupuncturist |
| DIAGNOSTIC FUNCȚIONAL | Cartografierea creierului computerizată / Examinare neuroenergometrică |
| DIAGNOSTIC FUNCȚIONAL | Electroencefalografie / Electroencefalogramă |
| DIAGNOSTIC FUNCȚIONAL | Reoencefalografie |
| DIAGNOSTIC FUNCȚIONAL | Examinare computerizată cu electrospondilografie |
| DIAGNOSTIC FUNCȚIONAL | Examinare electrocardiografică ECG computerizată |
| DIAGNOSTIC FUNCȚIONAL | Testări electrodiagnostice computerizate ale sistemelor și organelor umane MEDISKRIN PROFESSIONAL |
| DIAGNOSTIC FUNCȚIONAL | Examinare EHO-Encefalografie |
| DIAGNOSTIC FUNCȚIONAL | Examinarea cu ultrasunete a organelor interne |
| DIAGNOSTIC FUNCȚIONAL | Examen expres de laborator Uro-test |
| DIAGNOSTIC FUNCȚIONAL | Examinare neinvazivă 117 indici clinici Biopromin AMP-Tech |
| DIAGNOSTIC FUNCȚIONAL | Termalgometrie RUNO - Testarea cu feedback computerizat a sistemului nervos vegetativ |
| DIAGNOSTIC FUNCȚIONAL | Evaluare funcțională neuropsihologică |
| DIAGNOSTIC FUNCȚIONAL | Testare cognitivă avansată |
| DIAGNOSTIC FUNCȚIONAL | Evaluare biomecanică a mișcării |
| DIAGNOSTIC FUNCȚIONAL | Evaluare ergonomică personalizată |
| TESTĂRI PSIHODIAGNOSTICE COMPUTERIZATE | MMPI |
| TESTĂRI PSIHODIAGNOSTICE COMPUTERIZATE | Testări psihologice Luscher |
| TESTĂRI PSIHODIAGNOSTICE COMPUTERIZATE | Testări psihologice Sondy |
| TESTĂRI PSIHODIAGNOSTICE COMPUTERIZATE | Psihoterapie |
| TESTĂRI PSIHODIAGNOSTICE COMPUTERIZATE | Test de personalitate |
| TESTĂRI PSIHODIAGNOSTICE COMPUTERIZATE | Test de inteligență emoțională |
| TESTĂRI PSIHODIAGNOSTICE COMPUTERIZATE | Evaluare psihosocială |
| TESTĂRI PSIHODIAGNOSTICE COMPUTERIZATE | Test de stres post-traumatic |
| TESTĂRI PSIHODIAGNOSTICE COMPUTERIZATE | Evaluare a funcțiilor executive |
| FIZIOTERAPIE ȘI REABILITARE | Ședință de fizioterapie 30 min |
| FIZIOTERAPIE ȘI REABILITARE | Masaj terapeutic 60 min |
| FIZIOTERAPIE ȘI REABILITARE | Electroterapie combinată |
| FIZIOTERAPIE ȘI REABILITARE | Fizioterapie manuală 45 min |
| FIZIOTERAPIE ȘI REABILITARE | Reabilitare post-operatorie 60 min |
| FIZIOTERAPIE ȘI REABILITARE | Programe personalizate de exerciții |
| FIZIOTERAPIE ȘI REABILITARE | Reabilitare echilibrată și coordonată |
| TERAPIE BALNEARĂ | Băi curative cu nămol |
| TERAPIE BALNEARĂ | Hidroterapie |
| TERAPIE BALNEARĂ | Sauna terapeutică |
| TERAPIE BALNEARĂ | Masaj cu nămol 60 min |
| TERAPIE BALNEARĂ | Terapie cu vitamine și minerale |
| TERAPIE BALNEARĂ | Tratament combinat hidroterapie + masaj |
| ELECTROTERAPIE | Electrostimulare musculară |
| ELECTROTERAPIE | Electroneurostimulare |
| ELECTROTERAPIE | Electroterapie combinată |
| ELECTROTERAPIE | Terapie cu ultrasunete 30 min |
| ELECTROTERAPIE | Terapie cu curenți alternanți |
| ELECTROTERAPIE | Terapie cu curenți continui |
| ECHIPAMENTE ȘI METODE CURATIVE | Băi curative cu nămol din SAKI, Hidrosulfurică, cu magneziu, IodoBrom, Turbintina, extract de pin, băi de slăbit |
| ECHIPAMENTE ȘI METODE CURATIVE | Aeroionoterapia în peștera de sare |
| ECHIPAMENTE ȘI METODE CURATIVE | Sauna curativă cu plante |
| ECHIPAMENTE ȘI METODE CURATIVE | Fizioterapie + Naturoterapie |
| ECHIPAMENTE ȘI METODE CURATIVE | Vibro-masaj cranial |
| ECHIPAMENTE ȘI METODE CURATIVE | Instructor Visus computerizat |
| ECHIPAMENTE ȘI METODE CURATIVE | AVS stimularea creierului audio-video cu alfa, beta, theta |
| ECHIPAMENTE ȘI METODE CURATIVE | Darsanvalizare |
| ECHIPAMENTE ȘI METODE CURATIVE | Ozonoterapia |
| ECHIPAMENTE ȘI METODE CURATIVE | Electropunctură-Subosi |
| ECHIPAMENTE ȘI METODE CURATIVE | Magnetoterapie |
| ECHIPAMENTE ȘI METODE CURATIVE | Masaj KDJ |
| ECHIPAMENTE ȘI METODE CURATIVE | JAD-masaj pat cu pietre de jad |
| ECHIPAMENTE ȘI METODE CURATIVE | Vibromasaj de relaxare |
| ECHIPAMENTE ȘI METODE CURATIVE | Electroneurostimulare |
| ECHIPAMENTE ȘI METODE CURATIVE | Fototerapie / Cromoterapie |
| ECHIPAMENTE ȘI METODE CURATIVE | Radamir-3 FRI program cu frecvențe de biorezonanță revitalizare |
| ECHIPAMENTE ȘI METODE CURATIVE | Radamir-4 CVC program de frecvență a biorezonanței antiparazitare |
| ECHIPAMENTE ȘI METODE CURATIVE | Raze infraroșii + ultraviolete |
| ECHIPAMENTE ȘI METODE CURATIVE | Electroforeză medicală |
| ECHIPAMENTE ȘI METODE CURATIVE | Vibrofonoterapie Vitafon |
| ECHIPAMENTE ȘI METODE CURATIVE | Electroacupunctură |
| ECHIPAMENTE ȘI METODE CURATIVE | Electrosomn |
| ECHIPAMENTE ȘI METODE CURATIVE | Fototerapie Bioptron |
| ECHIPAMENTE ȘI METODE CURATIVE | Farmacopunctură / Mezoterapie |
| ECHIPAMENTE ȘI METODE CURATIVE | Electrostimulare plantară LANAFORM |
| ECHIPAMENTE ȘI METODE CURATIVE | Masajul plantar Vibro-Infraroșu |
| ECHIPAMENTE ȘI METODE CURATIVE | Acupunctura auriculară |
| ECHIPAMENTE ȘI METODE CURATIVE | Acupunctura corporală |
| ECHIPAMENTE ȘI METODE CURATIVE | Terapia cu laser |
| ECHIPAMENTE ȘI METODE CURATIVE | Masaj general |
| ECHIPAMENTE ȘI METODE CURATIVE | Terapia cu ultrasunete |
| ECHIPAMENTE ȘI METODE CURATIVE | Terapia Fotocataliza magnetică |
| ECHIPAMENTE ȘI METODE CURATIVE | Detoxifierea organismului ION-DETOX |
| ECHIPAMENTE ȘI METODE CURATIVE | Terapia cu Amplipuls |
| ECHIPAMENTE ȘI METODE CURATIVE | Electrostimulare mezodiencefalică transcraniană |
| ECHIPAMENTE ȘI METODE CURATIVE | Terapie combinată magnetoterapie + acupunctură |
| ECHIPAMENTE ȘI METODE CURATIVE | Biofeedback pentru controlul stresului |
| ECHIPAMENTE ȘI METODE CURATIVE | Masaj terapeutic profund |
| ECHIPAMENTE ȘI METODE CURATIVE | Terapie cu vibrații |
| ECHIPAMENTE ȘI METODE CURATIVE | Programe de reabilitare neuro-motorie |
| ECHIPAMENTE ȘI METODE CURATIVE | Tratament combinat electroterapie + kinetoterapie |
| ECHIPAMENTE ȘI METODE CURATIVE | Terapie cu frecvențe de biorezonanță |
| ECHIPAMENTE ȘI METODE CURATIVE | Electroterapie integrată |
| ECHIPAMENTE ȘI METODE CURATIVE | Reabilitare cu tehnologie avansată |
| ECHIPAMENTE ȘI METODE CURATIVE | Programe personalizate de recuperare |

## Additional mentions and scope distinctions

- `lib/site.ts` has Bemer/BEMER and electrostimulation legacy service slugs. BEMER has no matching dedicated route in the active six-service catalog. It remains an unconfirmed legacy mention, not a newly advertised service.
- `lib/services.ts` is the active six-service catalog; `services_admin` contains parallel database content. Consultation, physiotherapy, rehabilitation, functional diagnosis, balneotherapy and electrotherapy are the parent clusters.
- `lib/db.ts` contains seed data and mutations; the checked-in SQLite snapshot and build-time values can differ. No database edits are shipped. Existing prices are not independently verified and are not copied into new landing pages.
- `lib/staticBlogPosts.ts` contains educational references to laboratory tests, imaging, diet and cancer prevention. These do not establish that Revimed performs every mentioned test or offers oncology treatment.
- The digital applications mention Ayurveda, breathing, yoga, self-assessment, exercise, supplements and recovery suggestions. They are educational tools, not proof of a clinic device or a licensed treatment. Their individual medical algorithms and supplement advice need a separate clinical review.
- Database/gallery captions do not prove the make or model of photographed equipment. No exact model-photo match was made.
- `audit/source-index.json` records the text/source scan, including referenced local images. Original ZIP backups and the CSS backup are historical, not active routes.

## Before/after audit for all 25 equipment entries

Before: dedicated URLs existed, but equipment metadata lacked canonical/hreflang; descriptions were often brief or placeholders; no image was rendered by the equipment template; no related-service or appointment block; no patient FAQ. The English, Russian and Ukrainian catalogs mirror the Romanian device list.

After: RO/RU pages use eight clinically cautious method families, FAQs, photo captions, service links, contact/price CTAs and breadcrumb JSON-LD. All four languages get equipment metadata and images. EN/UA medical body copy remains legacy and is not represented as newly clinically reviewed. Model-specific evidence, photographs and protocols remain unresolved; family guidance should not be mistaken for independent verification of 25 models.

Every row is mapped in `EQUIPMENT_AND_PROCEDURES.csv`. Dedicated new pages were intentionally limited to EEG, ECG and internal-organ ultrasound. Other named methods remain visible and require confirmation/evidence before creating additional SEO landing pages.
