import { getStaticPostBySlug } from './staticBlogPosts';
import { blogSlugGroups } from './blogSlugTranslations';
import { patientMetadata } from './patientSeo';
import { siteUrl } from './seo';
import type { Lang } from './i18n';
export function blogMetadata(slug:string,lang:Lang) {
 const post=getStaticPostBySlug(slug,lang);if(!post)return {};
 const group=Object.values(blogSlugGroups).find(g=>Object.values(g).includes(slug));
 const copyLang=group && slug===group.ro && lang!=='ro' ? 'ro' : lang;
 const p=group?.[copyLang]||slug;
 const m=patientMetadata(post.title,post.excerpt,`/blog/${p}`,copyLang);
 m.alternates={canonical:`${siteUrl}${copyLang==='ro'?'':`/${copyLang}`}/blog/${p}/`,languages: group ? Object.fromEntries(Object.entries(group).map(([l,s])=>[l==='ua'?'uk':l,`${siteUrl}${l==='ro'?'':`/${l}`}/blog/${s}/`])) : {}};
 return m;
}
