import { patientMetadata } from './patientSeo';
import { normalizeLang } from './equipment';
const titles:Record<string,string[]>={
 'test-ayurveda-dosha':['Chestionar Ayurveda Dosha','Ayurveda Dosha questionnaire','Опросник Аюрведа Доша','Опитувальник Аюрведа Доша'],
 'respiratie-terapeutica':['Respirație ghidată','Guided breathing','Дыхательные упражнения','Дихальні вправи'],
 'revimed-yoga-tibetan':['Revimed Yoga Tibetan','Revimed Tibetan Yoga','Тибетская йога Revimed','Тибетська йога Revimed'],
 'screening-neurologic':['Autoevaluare neurologică','Neurological self-assessment','Неврологическая самооценка','Неврологічна самооцінка'],
 'calculator-recuperare-personalizata':['Calculator de recuperare','Recovery planner','Планировщик восстановления','Планувальник відновлення'],
 'test-postura-coloana':['Test postură și coloană','Posture and spine questionnaire','Опросник осанки и позвоночника','Опитувальник постави та хребта'],
 'monitor-dureri-spate':['Monitor dureri de spate','Back pain tracker','Дневник боли в спине','Щоденник болю в спині'],
 'test-risc-cadere-echilibru':['Test risc de cădere și echilibru','Falls and balance questionnaire','Опросник риска падений и равновесия','Опитувальник ризику падінь та рівноваги'],
 'planner-exercitii-zilnice':['Planificator de exerciții','Exercise planner','Планировщик упражнений','Планувальник вправ'],
 'test-stres-somn-respiratie':['Test stres, somn și respirație','Stress, sleep and breathing questionnaire','Опросник стресса, сна и дыхания','Опитувальник стресу, сну та дихання'],
 'pregatire-consultatie':['Pregătire pentru consultație','Consultation preparation','Подготовка к консультации','Підготовка до консультації']
};
export function toolMetadata(slug:string,rawLang:string){const lang=normalizeLang(rawLang);const i=['ro','en','ru','ua'].indexOf(lang);const title=titles[slug]?.[i];if(!title)return {};return patientMetadata(title,[`Instrument educațional pentru pregătirea discuției cu medicul. Nu stabilește un diagnostic.`,`Educational tool to prepare for a discussion with your clinician. It does not diagnose illness.`,`Образовательный инструмент для подготовки к разговору с врачом. Не устанавливает диагноз.`,`Освітній інструмент для підготовки до розмови з лікарем. Не встановлює діагноз.`][i],`/aplicatii/teste-si-instrumente/${slug}`,lang);}
