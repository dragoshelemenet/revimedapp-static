import type { Metadata } from 'next';
import { siteUrl } from './seo';
import { getLocalizedEquipmentItem } from './equipmentLocalized';
import { equipmentPatient } from './equipmentPatient';
import { investigations, type InvestigationSlug } from './investigations';
import type { SiteLang } from './equipment';
export function patientMetadata(title:string,description:string,path:string,lang:SiteLang,langs:SiteLang[]=['ro','ru','en','ua']):Metadata {
 const url=(l:SiteLang)=>`${siteUrl}${l==='ro'?'':`/${l}`}${path}/`;
 return {title:{absolute:`${title} | Revimed PLUS+`},description,alternates:{canonical:url(lang),languages:Object.fromEntries([...langs.map(l=>[l==='ua'?'uk':l,url(l)]),['x-default',url('ro')]])},openGraph:{type:'website',title,description,url:url(lang),locale:lang==='ru'?'ru_MD':lang==='ro'?'ro_MD':lang==='ua'?'uk_UA':'en_GB',images:[{url:`${siteUrl}/images/revimed-chisinau-receptie-960.webp`,alt:'Revimed PLUS+ — Chișinău'}]},twitter:{card:'summary_large_image',title,description,images:[`${siteUrl}/images/revimed-chisinau-receptie-960.webp`]}};
}
export function equipmentMetadata(slug:string,lang:SiteLang) {
 const item=getLocalizedEquipmentItem(lang,slug); if(!item) return {};
 const p=equipmentPatient(item,lang);
 const title=`${item.title}${lang==='ru'?' в Кишинёве':lang==='ro'?' în Chișinău':lang==='ua'?' у Кишиневі':' — Chișinău'}`;
 const description=p ? (lang==='ru'?`${item.title}: применение, ограничения, подготовка и вопросы перед записью в Revimed PLUS+, Кишинёв. Уточните модель, доступность и цену.`:`${item.title}: utilizare, limite, pregătire și întrebări înainte de programare la Revimed PLUS+, Chișinău. Confirmați modelul, disponibilitatea și prețul.`) : item.short;
 return patientMetadata(title,description,`/utilaj/${slug}`,lang);
}
export function investigationMetadata(slug:string,lang:'ro'|'ru') {
 if(!Object.hasOwn(investigations,slug)) return {};
 const c=investigations[slug as InvestigationSlug][lang];
 return patientMetadata(c.title,c.description,`/investigatii/${slug}`,lang,['ro','ru']);
}
