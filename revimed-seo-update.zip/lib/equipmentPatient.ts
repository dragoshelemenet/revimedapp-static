import data from './equipmentPatientData.json';
import type { EquipmentItem, SiteLang } from './equipment';

export function equipmentGroup(slug: string): keyof typeof data {
 if (slug === 'aparat-amp') return 'amp';
 if (slug.startsWith('amplipuls')) return 'amplipuls';
 if (slug.includes('electroforeza')) return 'ionto';
 if (slug === 'spectr-lc' || slug === 'lampa-solux') return 'heat';
 if (slug.startsWith('kandadzia')) return 'massage';
 if (slug.includes('detox')) return 'detox';
 if (slug === 'rheotest') return 'rheo';
 return 'cranial';
}
export function equipmentPatient(item: EquipmentItem, lang: SiteLang) {
 if (lang !== 'ro' && lang !== 'ru') return null;
 const group = data[equipmentGroup(item.slug)];
 const copy = group[lang];
 const ru = lang === 'ru';
 return {
  heading: copy[0], description: copy[1], service: group.service, sources: group.sources,
  sections: [
   {title: ru ? 'Что это за метод' : 'Ce este metoda', body: [copy[1]]},
   {title: ru ? 'Возможности и ограничения' : 'Posibilități și limite', body: [copy[2]]},
   {title: ru ? 'Подготовка и безопасность' : 'Pregătire și siguranță', body: [copy[3]]},
  ],
  faq: [
   {q: copy[4], a: copy[5]},
   {q: ru ? 'Сколько длится сеанс и сколько нужно процедур?' : 'Cât durează ședința și câte proceduri sunt necesare?', a: ru ? 'Для этой модели центр не опубликовал подтвержденный протокол. До оплаты уточните длительность, число посещений, критерии оценки результата и условия прекращения курса. Универсального числа сеансов нет.' : 'Centrul nu a publicat un protocol confirmat pentru acest model. Înainte de plată, întrebați durata, numărul vizitelor, criteriile de evaluare a rezultatului și când se oprește cura. Nu există un număr universal de ședințe.'},
   {q: ru ? 'Как узнать цену в Кишинёве?' : 'Cum aflu prețul în Chișinău?', a: ru ? 'Посмотрите прайс-лист и подтвердите стоимость по телефону. Уточните, включены ли консультация, расходные материалы и интерпретация результата. Наличие модели и время приема также нужно подтвердить.' : 'Consultați lista de prețuri și confirmați costul telefonic. Întrebați dacă sunt incluse consultația, consumabilele și interpretarea rezultatului. Confirmați și disponibilitatea modelului și ora programării.'},
   {q: ru ? 'Что делать после процедуры?' : 'Ce fac după procedură?', a: ru ? 'Попросите индивидуальные рекомендации и срок повторной оценки. Сообщите врачу о новых или усилившихся симптомах. Не меняйте назначенное лечение самостоятельно.' : 'Cereți recomandări individuale și termenul reevaluării. Comunicați medicului simptomele noi sau agravate. Nu modificați singur tratamentul prescris.'},
  ]
 };
}
