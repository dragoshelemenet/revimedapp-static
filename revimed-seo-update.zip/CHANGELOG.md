# Revimed PLUS+ SEO update — 11 November 2026

Base: `dragoshelemenet/revimedapp-static`, main commit `837b6f53a840b34f250a2ef107684571cf0a4a8e`.

## Implemented

- Preserved every existing page and all 25 equipment catalog entries. Improved the 25 Romanian and 25 Russian equipment pages with patient guidance, practical FAQs, related service links, price/contact/call actions and visible medical sources where available.
- Added six static pages: Romanian and Russian EEG, ECG and internal-organ ultrasound guides under `/investigatii/` and `/ru/investigatii/`. These procedures are explicitly present in the repository's price database.
- Corrected the presentation of AMP and ionic DETOX: no claim that AMP replaces blood tests or that a foot bath removes toxins. Removed unsupported model specifications and treatment promises from the new RO/RU equipment rendering. Original catalog records remain in source.
- Added responsive WebP derivatives of two existing clinic photographs. Captions explicitly distinguish clinic-room photographs from actual device photographs.
- Added canonical, language-alternate, Open Graph and Twitter metadata to equipment/service pages, plus translated top-level pages, tools and blog records that previously inherited generic metadata.
- Retained `/servicii/consultatii-neurochirurgicale/` as an accessible alias and restored the catalog's `/servicii/consultatii-neurochirurgie/` route, with canonical pointing to the latter.
- Corrected broken translated legal/FAQ links and language-switching blog slugs. Untranslated legal/FAQ content links to its existing Romanian route.
- Replaced existing localized video placeholders with the existing gallery content and a gallery canonical. No route deleted.
- Removed duplicate conflicting clinic schema, unconfirmed opening hours/coordinates/price range from the active clinic entity, and a nonfunctional SearchAction. MedicalClinic is already a LocalBusiness subtype; another conflicting business entity is unnecessary.
- Made price-row text present in exported HTML even when accordion panels start closed.
- Added a static postbuild step: correct HTML language attributes, prune nonexistent hreflang targets, generate sitemap from actual canonical HTML, and output robots.txt with the configured domain. Use `npm run build`, not `next build` alone.
- Fixed fixed-height hero clipping for long equipment names; added restrained patient-content styling.
- Added source inventory, procedure mapping, medical-source notes and repeatable static checks.

## Confirm with the clinic before publication

1. Correct production domain (repository defaults to `https://revimed.site`), opening hours (09–15, 09–16 and 09–19 occur in source), email and map coordinates. Existing visible hours are retained; schema omits them.
2. Physical availability and exact labels/manuals for every device, especially grouped Transair names, AMP/Biopromin, LENAR, MDM, Spectr-LC, RHEOTEST and KDJ.
3. Clinician sign-off on the new patient copy; no invented medical reviewer, approval or review date is attached.
4. Current prices, appointment duration, required referral, who interprets EEG/ECG/ultrasound, and exact examination scope. No new prices or fixed treatment courses were invented.
5. Rights and patient consent for existing photographs. No new external stock or manufacturer images were copied.
6. Legacy EN/UA medical copy and price-list marketing labels (bioresonance/antiparasitic, ozone, detox, weight-loss baths, etc.) still need clinical review. They were preserved, not endorsed.

## Verification scope

See `SEO_REPORT.md` and `audit/static-check.json`. Production static export was performed; no GitHub commit, push or deployment was made. A nonfatal Turbopack tracing warning from the existing local persistence helper remains. No real-world ranking improvement or Core Web Vitals pass is claimed.
